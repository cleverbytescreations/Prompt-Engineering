# CLAUDE.md

## Project Summary
Restricted ICA legal knowledge and collaboration platform.
Core goals:
- legal knowledge repository
- expert Q&A
- knowledge articles (promoted Q&A pairs)
- curated news
- social feed / posts
- AI-assisted hybrid search and RAG answers
- multi-language support (EN / ES / FR)

Principles:
- AI is assistive, not authoritative
- moderation is core — all UGC is pending until approved
- human validation is required for legal interpretation

## Tech Stack
Frontend: Next.js, React, TypeScript, MUI, Tailwind, next-intl
Backend: FastAPI, SQLAlchemy, Redis, Celery
Data: PostgreSQL (system of record), OpenSearch (BM25 + k-NN hybrid search, vector store), MinIO (dev) / AWS S3 (prod)

## Skill Routing
Use `architecture-deep-dive` for architecture, workflows, scalability, RAG, storage, and search design.
Use `frontend-guidelines` for all work inside `frontend/`, including UI, forms, mocks, API contracts, and React patterns.
Use `backend-patterns` for FastAPI backend design, services, repositories, async processing, and integration patterns.

## Key Rules
- Stay inside correct module boundary; no business logic in UI
- Frontend: React Query for data fetching; clean backend layering: API → Service → Repository
- CQRS: writes → PostgreSQL; search/discovery → OpenSearch (no member-facing FTS on PostgreSQL)
- All UGC is pending until moderated; never bypass the queue
- Transactional outbox: domain events write to `outbox_events` in the same PG transaction as state change
- Two Redis instances: `redis-broker` (db=0 Celery broker) · `redis-cache` (db=0 search cache · db=1 translation cache) — never mix instances or DB slots
- Heavy tasks (OCR, embedding, translation, notifications) are always async via Celery
- `NEXT_PUBLIC_DEMO_MODE=true` enables MSW mocks

## Code navigation policy

Prefer LSP for `.ts`, `.tsx`, `.py` symbol lookup; use Grep only as fallback for config strings, comments, or non-symbol literals.