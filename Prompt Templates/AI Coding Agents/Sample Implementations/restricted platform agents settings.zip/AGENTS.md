# AGENTS.md

## Project Summary
ICA Restricted Legal Platform is an invite-only legal knowledge and collaboration system for ICA staff, legal professionals, moderators, and member organisations. It consolidates cooperative law documents, expert Q&A, curated news, moderated social collaboration, and AI-assisted discovery in a secure auditable environment.

Core goals:
- Governed legal knowledge repository
- Expert-moderated Q&A and discussion
- Curated legal news and member collaboration
- Hybrid keyword + semantic search

Principles:
- AI is assistive, never authoritative legal advice
- Moderation is core; unvetted member content must not reach members
- Human validation is required for legal interpretation
- Privacy, auditability, and organisation scoping are first-class concerns

## Tech Stack
Frontend: Next.js 16 App Router, React 19, TypeScript, MUI 9, Tailwind CSS 4, TanStack React Query 5, Zustand, React Hook Form, Zod, MSW, next-intl
Backend: FastAPI, SQLAlchemy 2 async, Alembic, Pydantic v2, custom OAuth2/JWT with RS256, slowapi
Data: PostgreSQL, PgBouncer, OpenSearch 2.x with BM25 + k-NN vectors, MinIO/S3
Infra: Redis broker/cache split, Celery 5 workers, Redbeat, Dockerfile-based backend, pytest, ESLint, TypeScript

## Skill Routing
Use `architecture-deep-dive` for architecture, workflows, scalability, search/RAG, storage, cache strategy, and async/event design.
Use `frontend-guidelines` for all work inside `frontend/`, including UI, forms, state, mocks, i18n, and API contracts.
Use `backend-patterns` for FastAPI backend design, services, repositories, migrations, workers, queues, caching, and integration patterns.

## Key Rules
- Keep work inside the correct module boundary.
- API -> Service -> Repository -> Model; no business logic in route handlers.
- SQLAlchemy query construction belongs in `backend/app/repositories/`.
- React Query owns frontend server state; Zustand is for auth/role/light UI state.
- CQRS writes -> PostgreSQL; member discovery/search -> OpenSearch.
- See `architecture-deep-dive` for Redis slot, search/vector, and storage separation rules.
- See `backend-patterns` for the transactional outbox implementation spec.
- Heavy OCR, indexing, embedding, translation, notification, and AI work runs through Celery.
- `NEXT_PUBLIC_DEMO_MODE=true` enables MSW mocks.

## Code Navigation Policy
Prefer LSP for `.ts`, `.tsx`, and `.py` symbol lookup; use Grep only as fallback for config strings, comments, TODOs, and non-symbol literals.
