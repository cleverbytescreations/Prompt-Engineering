# /lint-fix

Run linter and type checker on the backend, then fix any issues found.

## Instructions

1. Run ruff (auto-fix safe issues):
   ```bash
   cd backend && ruff check app/ --fix --select E,F,W,I -q
   cd backend && ruff format app/ -q
   ```

2. Run mypy:
   ```bash
   cd backend && mypy app/ --ignore-missing-imports --no-error-summary 2>&1 | grep -v "^Found"
   ```

3. Fix any remaining ruff errors manually:
   - Use LSP `hover` to check types before adding annotations
   - Do not suppress errors with `# type: ignore` unless truly unavoidable
   - Prefer fixing the root cause

4. Re-run to confirm clean:
   ```bash
   cd backend && ruff check app/ -q && echo "ruff: OK"
   ```

5. Report: count of issues fixed, any remaining issues with file:line.
