# /migrate

Generate and apply an Alembic migration for the current phase's ORM changes.

## Argument
Pass migration name: `/migrate consultant_pool`

## Instructions

1. Check current migration state:
   ```bash
   cd backend && alembic current
   ```

2. Generate migration (autogenerate from model changes):
   ```bash
   cd backend && alembic revision --autogenerate -m "$ARGUMENT"
   ```

3. **Review the generated file** in `backend/alembic/versions/` before applying:
   - Confirm `upgrade()` creates expected tables/columns
   - Confirm `downgrade()` reverses cleanly
   - Check for any missed `schema` qualifications on tenant tables
   - Verify GIN indexes are present where expected (search snapshots)

4. Apply migration:
   ```bash
   cd backend && alembic upgrade head
   ```

5. Verify:
   ```bash
   cd backend && alembic current
   ```

6. If migration fails:
   - Do NOT delete migration files — downgrade first: `alembic downgrade -1`
   - Fix the model and regenerate

## Important
- Never edit the DB directly — always go through Alembic.
- All tables use a single PostgreSQL schema (no multi-tenancy); all migrations go through Alembic.
