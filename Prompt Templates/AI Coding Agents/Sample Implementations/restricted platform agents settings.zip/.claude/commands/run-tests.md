# /run-tests

Run the appropriate test suite for the current phase and report results.

## Argument
Optional: `/run-tests unit` | `/run-tests integration` | `/run-tests all`  
Default: runs unit + integration tests.

## Instructions

1. Determine which test files exist:
   ```bash
   ls backend/tests/
   ```

2. Run tests with coverage:
   ```bash
   cd backend && pytest tests/ -x -q --tb=short --co -q 2>&1 | head -30
   cd backend && pytest tests/ -x -q --tb=short 2>&1 | tail -30
   ```

3. If tests fail:
   - Read only the failing test file and the service it tests (using LSP for definitions).
   - Fix the root cause — do not mock away real failures.
   - Re-run the specific failing test before re-running the suite.

4. Report:
   - Pass/fail count
   - Coverage % if available
   - Any skipped tests and why
   - Next step if red (specific file:line to fix)

Keep output concise — no full tracebacks unless needed to diagnose.
