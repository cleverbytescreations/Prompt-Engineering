# /session-end

Wrap up the current session: verify work, update checklist, commit.

## Argument
Pass the phase number worked on: `/session-end 3`

## Instructions

### 1. Verify lint is clean
```bash
cd backend && ruff check app/ -q && echo "OK"
```
Fix any errors before proceeding.

### 2. Run tests
```bash
cd backend && pytest tests/ -x -q --tb=short 2>&1 | tail -15
```
Do not commit if tests are red.

### 3. Update checklist
Run `/update-checklist $PHASE` — mark all verified tasks `[x]`.

### 4. Commit
```bash
git status
git add backend/app/ backend/alembic/ Docs/tasks.md
git commit -m "Phase $PHASE: <summary of what was implemented>"
```

### 5. Report session summary
Output in this format (max 10 lines):
```
Phase N — <name>
Files added : <count> (<list>)
Files edited: <count> (<list>)
Tests       : <pass>/<total>
Checklist   : <X> tasks marked complete
Next session: Phase N+1 — <first task>
```
