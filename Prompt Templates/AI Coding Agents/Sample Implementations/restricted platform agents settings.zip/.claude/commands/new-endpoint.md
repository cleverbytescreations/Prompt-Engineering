# /new-endpoint

Scaffold a new API endpoint following the ICA platform pattern. Generates schema, repository query, service method, and route — all consistent with existing code style.

## Argument
`/new-endpoint <domain> <verb> <resource>`
Example: `/new-endpoint questions POST /questions/{id}/answers`

## Endpoint Pattern (do not deviate)

### 1. Pydantic Schema — `backend/app/schemas/<domain>.py`
```python
class <Resource>Create(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    # fields here

class <Resource>Response(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    created_at: datetime
    # fields here
```

### 2. Repository query — `backend/app/repositories/<domain>_repository.py`
```python
async def get_<resource>(db: AsyncSession, entity_id: UUID) -> <Model> | None: ...
async def create_<resource>(db: AsyncSession, data: dict) -> <Model>: ...
```

### 3. Service method — `backend/app/services/<domain>_service.py`
```python
async def <action>_<resource>(<params>) -> <Resource>Response:
    async with get_db_session() as db:
        result = await <domain>_repo.<action>_<resource>(db, ...)
        # business logic here
        return result
```

### 4. Route — `backend/app/api/v1/endpoints/<domain>.py`
```python
@router.<method>("<path>", response_model=<Resource>Response, status_code=<N>)
async def <action>_<resource>(
    current_user: User = Depends(get_current_active_user),
    <params>,
):
    return await <domain>_service.<action>_<resource>(...)
```

## Instructions

1. Use `LSP goto_definition` on the nearest existing endpoint in the same file to confirm current imports and router variable name — do NOT re-read the whole file.
2. Add the schema class(es) to the existing schemas file with a single `Edit`.
3. Add the repository query function(s) to the existing repository file.
4. Add the service method to the existing service file.
5. Add the route to the existing endpoints file.
6. Run lint: `cd backend && ruff check app/ -q --select E,F,I`
7. Report what was added (4 locations, no more).
