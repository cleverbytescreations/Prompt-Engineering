# /fix-error

Efficiently diagnose and fix a specific error without reading unrelated code.

## Argument
Paste the error/traceback after the command: `/fix-error <traceback>`

## Instructions

### Step 1 — Parse the traceback
Extract from the traceback:
- The exact file and line number where the error originates
- The error type and message
- Any chained cause

### Step 2 — Read only what's needed
- Use `Read` with `offset` and `limit` to read ±20 lines around the failing line — not the whole file.
- Use `LSP hover` on the failing symbol to check its type/signature.
- Use `LSP goto_definition` if the error is about a missing or mistyped attribute.

### Step 3 — Fix
Apply the minimal change. Do not refactor surrounding code.

### Step 4 — Verify
Re-run only the failing test or command. Do not run the full suite unless the fix touches shared utilities.

```bash
cd backend && pytest <specific_test_file>::<test_name> -x -q
```

### Step 5 — Report
One sentence: what was wrong and what was changed. File:line reference.

## Token rules
- Never read a file in full to find a bug — always use line-targeted `Read`.
- Never re-read a file you just edited.
- If the error is in a dependency (not your code), check the traceback for the last frame that IS your code.
