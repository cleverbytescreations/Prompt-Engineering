# /impl-phase

Implement the next incomplete phase of the ICA platform, following the plan exactly.

## Argument
Pass the phase number: `/impl-phase 3`  
If no argument given, detect the next incomplete phase from the checklist.

## Instructions

### Step 1 — Scope
Read only the relevant phase section from `Docs/tasks.md`.
Do NOT re-read the full implementation plan — all architecture context is in `CLAUDE.md`.

### Step 2 — Navigate with LSP, not file search
- Use `LSP goto_definition` to find base classes, imported symbols.
- Use `LSP find_references` before modifying shared utilities.
- Use `LSP hover` to check types and signatures.
- Only use `Read` with `offset`+`limit` for a known file section, never whole files unless under 100 lines.

### Step 3 — Implementation order (always follow this sequence)
1. ORM models (if any) → `backend/app/models/<domain>.py`
2. Alembic migration: `cd backend && alembic revision --autogenerate -m "<phase_name>"` → review the generated file
3. Pydantic schemas → `backend/app/schemas/<domain>.py`
4. Repository layer → `backend/app/repositories/<domain>_repository.py` (all queries here; no raw queries in service)
5. Service layer → `backend/app/services/<domain>_service.py` (calls repository; owns session and business logic)
6. API endpoints → `backend/app/api/v1/endpoints/<domain>.py`
7. Register router in `backend/app/api/v1/router.py` (if new endpoint file)
8. Celery tasks (if any) → `backend/app/workers/tasks/<domain>.py`

### Step 4 — Quality gates (run after each file)
```bash
cd backend && ruff check app/ --select E,F,W -q
cd backend && mypy app/<changed_file> --ignore-missing-imports
```

### Step 5 — Test
```bash
cd backend && pytest tests/ -x -q
```

### Step 6 — Update checklist
Mark completed items with `[x]` in `Docs/tasks.md`.
Update the phase status line to `✅ Complete` and set today's date.
Update the `## Overall Progress` table at the bottom.

### Token-saving rules
- Do not re-read files you just wrote.
- Do not read the full implementation plan — use `CLAUDE.md`.
- Batch related edits in one `Edit` call where possible.
- Stop and confirm with user before any destructive DB operations.
