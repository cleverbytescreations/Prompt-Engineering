# /phase-status

Show the current implementation phase and the exact next tasks to work on.

## Instructions

1. Read `Docs/tasks.md` — focus only on the first phase marked `📅` (not yet complete).
2. List every unchecked `[ ]` item in that phase, grouped by section (ORM Models, Schemas, Service, API).
3. Summarise which items can be done in parallel vs sequentially.
4. Output a prioritised work order for the session — **no implementation, just the plan**.

Keep output under 40 lines.
