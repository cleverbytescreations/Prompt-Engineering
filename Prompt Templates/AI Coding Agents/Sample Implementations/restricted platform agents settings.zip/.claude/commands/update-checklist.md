# /update-checklist

Mark completed tasks in the implementation checklist and update phase status.

## Argument
Pass phase number: `/update-checklist 3`

## Instructions

1. Read only the relevant phase section from `Docs/tasks.md`.

2. For each task, verify completion by checking the actual file exists and has the expected content:
   - For ORM models: check class exists in `backend/app/models/<domain>.py` using LSP
   - For schemas: check class exists in `backend/app/schemas/<domain>.py` using LSP
   - For repositories: check functions exist in `backend/app/repositories/<domain>_repository.py` using LSP (confirm no raw `select()`/`insert()`/`update()`/`delete()` in service files)
   - For services: check function exists in `backend/app/services/<domain>_service.py` using LSP
   - For API endpoints: check route exists in `backend/app/api/v1/endpoints/<domain>.py` using LSP

3. Mark verified items `[x]`. Leave unverified items `[ ]`.

4. If all items in a phase are `[x]`:
   - Change phase header from `📅` to `✅`
   - Add completion date line: `> **Phase N completed:** YYYY-MM-DD`
   - Update `## Overall Progress` table at bottom: change `📅 Planned` to `✅ Complete` with today's date

5. Save the file with all changes in a single Edit call.

## Token rule
Do not re-read the full checklist — read only the phase section you are updating.
