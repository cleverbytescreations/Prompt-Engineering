---
name: frontend-guidelines
description: Use for all work inside frontend, including Next.js app router, React, TypeScript, MUI, Tailwind, React Query, Zustand, forms, mocks, API contracts, and UI task execution.
---

# Frontend Guidelines

Use this skill when the task involves:
- any file inside `frontend/`
- page creation
- component design
- React / Next.js implementation
- form handling
- validation
- state management
- mock APIs
- frontend folder placement
- TypeScript typing
- UI task execution

## Scope Rules

- all frontend work must stay inside `frontend/`
- do not create files outside `frontend/` unless explicitly adding root-level documentation
- use the existing module structure
- do not invent new top-level frontend architecture unless justified

## Frontend Stack

Primary technologies:
- Next.js App Router
- React
- TypeScript
- MUI
- Tailwind
- TanStack React Query
- Zustand
- React Hook Form
- Zod
- MSW for demo/mock mode
- `next-intl` for internationalisation (EN / ES / FR)

## Import Rules

- use `@/` path alias for imports
- avoid deep relative imports like `../../..` across module boundaries

## UI Design Rules

- prefer MUI for interactive UI elements
  - buttons
  - inputs
  - dialogs
  - chips
  - tables where appropriate
- use Tailwind mainly for layout and spacing
- keep visual behavior consistent across modules
- favor reusable shared components when they genuinely reduce duplication

### law_status Badge Rule
Search result cards and document detail pages must display a prominent badge when `law_status != 'active'`:
- `Retracted` — warning/red color; label: "Retracted"
- `Superseded` — muted/grey color; label: "Superseded"
The default search only returns `active` documents; retracted items only appear with `?status=retracted`.

### Dev-mode Latency Badge
`SearchLatencyBadge` component: shown only when `process.env.NODE_ENV === 'development'`. Renders `latency_ms` and `cache_hit` from the search response envelope. Never shown in production builds.

## Component Rules

- use PascalCase file names
- one component per file unless a very small local helper is justified
- keep components presentation-focused
- do not put business logic in UI components
- move stateful data fetching logic into hooks or module APIs

## Data Fetching Rules

- API calls should go through React Query patterns
- do not fetch directly inside UI components unless there is a very small local-only reason
- prefer typed API client functions in `lib/api`
- align request/response types with the implementation plan

## Forms Rules

- use React Hook Form
- use Zod validation
- keep validation schemas explicit
- avoid loosely typed form payloads
- surface validation errors clearly in UI

## State Rules

- use Zustand only for appropriate shared client state
  - auth
  - role
  - lightweight UI state shared across modules
- do not move server state into Zustand when React Query is the right tool

## Mock / Demo Mode Rules

When `NEXT_PUBLIC_DEMO_MODE=true`:
- use MSW handlers
- handlers must match actual API contract shape
- include realistic latency, usually 100–400ms
- use realistic fixture data

## Source of Truth

For frontend task execution:
- `Docs/ui-tasks.md` is the task checklist
- `Docs/ui-implementation-plan.md` is the API contract source of truth

When implementing:
- check the relevant task first
- update task status when appropriate
- keep mock responses aligned to the documented contract

## Directory Guidance

Examples of intended grouping:
- pages/routes under `app/`
- reusable UI under `components/`
- per-module query hooks under `hooks/`
- typed API helpers under `lib/api/`
- global/shared state under `store/`
- shared TS types under `types/`
- mocks under `mocks/`

### Key shared components (place in `components/shared/`)
- `ReactionBar.tsx` — LIKE / ENDORSE / INSIGHTFUL buttons with counts; rendered on PostCard, AnswerCard, NewsCard, KnowledgeCard; calls `POST /react`
- `BookmarkButton.tsx` — toggle bookmark; calls `POST /bookmarks` or `DELETE /bookmarks/{type}/{id}`; rendered on DocumentCard, QuestionCard, KnowledgeCard, NewsCard
- `SearchLatencyBadge.tsx` — dev-mode only; shows `latency_ms` + `cache_hit` from response envelope

### Key new pages / routes
- `/knowledge` — `KnowledgeListPage.tsx` (browseable promoted Q&A articles)
- `/knowledge/[id]` — `KnowledgeDetailPage.tsx`
- `/profile/bookmarks` — `MyBookmarksPage.tsx` (user's saved items grouped by type)
- `/notifications/preferences` — `NotificationPreferencesPage.tsx` (per-type toggles)

### Key new components (place in module directories)
- `PromoteToKnowledgeDialog.tsx` — in `components/questions/`; Moderator/Admin action on QuestionDetailPage
- `RetractDocumentDialog.tsx` — in `components/moderation/`; Confirm retract / mark superseded; calls `PATCH /documents/{id}/status`
- `KnowledgeCard.tsx` — in `components/knowledge/`
- `LanguageSwitcher.tsx` — in `components/layout/`; dropdown in Header; uses `next-intl`

Before creating a file:
- confirm the target module/directory is correct
- prefer existing patterns over introducing a new pattern

## When generating frontend output

Prefer:
- exact file paths
- minimal but production-usable code
- typed props and payloads
- reusable patterns aligned to current structure
- short explanation of where each file belongs

## Avoid

- direct backend assumptions not in the documented contract
- mixing business rules into presentation components
- bypassing React Query patterns
- ad hoc fetch calls scattered in the UI
- inconsistent form or validation approaches