---
name: backend-patterns
description: Use for FastAPI backend design, clean architecture, services, repositories, async workflows, queues, caching, OCR/AI processing orchestration, and scalable backend implementation.
---

# Backend Patterns

Use this skill when the task involves:
- FastAPI design
- backend module structure
- service/repository boundaries
- database interaction
- async/background processing
- Redis/Celery usage
- OCR/AI orchestration
- API design
- backend scalability
- integration patterns

## Backend Baseline

Preferred backend stack:
- FastAPI
- SQLAlchemy / SQLModel
- Pydantic
- JWT auth
- Redis
- Celery or equivalent workers

## Backend Architecture Rule

Use clean layering:
1. **API layer** — `backend/app/api/v1/endpoints/<domain>.py` — HTTP concerns only: parse request, call service, return response
2. **Service layer** — `backend/app/services/<domain>_service.py` — business logic, orchestration, state transitions, outbox event creation
3. **Repository layer** — `backend/app/repositories/<domain>_repository.py` — all SQLAlchemy queries; receives `AsyncSession`; returns ORM models or scalars
4. **Model/data layer** — `backend/app/models/` — ORM definitions only

API → Service → Repository → Model. Services own sessions and pass `db` into repository functions. No `select()`/`insert()`/`update()`/`delete()` in service or endpoint files.

## API Design Rules

- keep endpoints explicit and predictable
- use typed Pydantic request/response schemas — never expose ORM models directly
- validate input at the API layer (Pydantic rejects before reaching services)
- enforce RBAC via `require_role` dependency at the route level
- return predictable response shapes; include `status_code` on write endpoints

## Service Layer Rules

- one file per domain: `backend/app/services/<domain>_service.py`
- service functions own the session: `async with get_db_session() as db:`
- service function signatures **never** receive an `AsyncSession` param — they open the session internally
- services own business logic, validation, state transitions, and outbox event creation — not HTTP concerns
- services must NOT contain `select()` / `insert()` / `update()` / `delete()` — delegate all DB access to the repository
- services open the session and pass `db` to repository functions: `result = await <domain>_repo.get_by_id(db, id)`
- a service may call repositories from multiple domains within one session for cross-domain orchestration
- do not place business rules directly in route handlers

## Repository Layer Rules

- one file per domain: `backend/app/repositories/<domain>_repository.py`
- all functions are `async def`, accept `db: AsyncSession` as first param, return ORM model(s) or scalar values
- no business logic — only query construction, execution, and result mapping
- no `HTTPException` in repositories — raise `ValueError` or return `None`; the service decides how to handle it
- repositories are stateless — use module-level functions, not class instances with internal state
- sessions are always opened by the service, never inside a repository function
- always use `await db.execute(select(...))` pattern — never sync queries

Canonical function signatures:
```python
async def get_by_id(db: AsyncSession, entity_id: UUID) -> Model | None: ...
async def list_with_filters(db: AsyncSession, filters: FilterSchema) -> list[Model]: ...
async def create(db: AsyncSession, data: dict) -> Model: ...
async def update(db: AsyncSession, entity: Model, changes: dict) -> Model: ...
async def delete(db: AsyncSession, entity_id: UUID) -> None: ...
```

## Async / Background Rules

Use background workers for:
- OCR
- indexing
- embedding generation
- notification fanout
- heavy summarization or document processing

Do not block request/response cycles with heavy work.

Typical pattern:
1. accept request
2. persist initial state
3. enqueue async job
4. return status or job-tracking response

## Redis Rules

Use Redis for:
- caching
- queueing in MVP
- short-lived workflow state where appropriate

Do not treat Redis as the system of record.

## Search / AI Integration Rules

Backend should orchestrate, not collapse, these concerns:
- PostgreSQL for transactions (system of record)
- OpenSearch for keyword search (BM25) AND semantic retrieval (k-NN) — these are the same system, not two separate stores
- object storage (MinIO / S3) for files

Maintain clear boundaries between them.

### SearchCacheService
Implement `SearchCacheService` (`backend/app/services/search_cache_service.py`) to:
- Check Redis db=1 before executing search (`search:{sha256(canonical_params)}`)
- Write result to Redis db=1 with TTL 300s after search executes
- Maintain scope sets (`scope:{country}:{category}` → SET of cache keys) for targeted invalidation
- Expose `invalidate_scope(country, category)` called by `search_cache_invalidate_job`

Implement `SearchCacheMiddleware` at FastAPI level: intercepts `GET /api/v1/search`, returns cached response with `cache_hit: true` immediately (skips `SearchService` entirely).

### Redis DB Slot Strategy
See **architecture-deep-dive skill → Cache / Queue** for canonical DB slot assignments and TTL rules.

## OCR / AI Workflow Rules

A typical backend flow:
1. upload file metadata
2. store asset in object storage
3. moderation review / approval
4. on approval: enqueue `document_ingestion_job` (OCR)
5. `chunking_job` — split into 512-token chunks with 64-token overlap; max 200 chunks per doc
6. `embedding_generation_job` — batch-embed in groups of **32 chunks** per Celery task; write vectors to OpenSearch k-NN field
7. `search_index_job` — index BM25 text fields + pre-computed vector into OpenSearch

AI and OCR outputs should be traceable and reviewable.

## Transactional Outbox Pattern

All domain events (approval, rejection, retraction, superseded) must:
1. Write an `outbox_events` row **in the same PostgreSQL transaction** as the state change
2. Never dispatch Celery jobs directly from the API handler without the outbox

An outbox polling worker (`outbox_worker.py`, Celery beat every 5s) reads `PENDING` events and dispatches to the appropriate Celery queue. Sets `PUBLISHED` on success, `FAILED` on error, `DEAD_LETTER` after 5 retries.

This guarantees no lost jobs if the API process crashes between the DB write and the queue push.

## Polymorphic Data Patterns

### Reactions
Use a single polymorphic `reactions` table: `entity_type IN ('POST','COMMENT','ANSWER','KNOWLEDGE_ARTICLE','NEWS_ITEM')`, `reaction_type IN ('LIKE','ENDORSE','INSIGHTFUL')`. Do not create entity-specific like/react tables.

API: `POST /react` (upsert, toggle-off on repeat), `GET /react/{entity_type}/{entity_id}`.

### Bookmarks
Use a single polymorphic `bookmarks` table: `entity_type IN ('DOCUMENT','QUESTION','ANSWER','KNOWLEDGE_ARTICLE','NEWS_ITEM','POST')`.

API: `POST /bookmarks`, `DELETE /bookmarks/{entity_type}/{entity_id}`, `GET /bookmarks`.

## Security Rules

- enforce RBAC
- enforce organization-level access rules
- treat legal/knowledge moderation as a core control point
- ensure sensitive operations are auditable
- do not expose private internal processing artifacts unless intended

## Performance Rules

- use async I/O where appropriate
- cache carefully
- batch expensive processing where possible
- keep read/search traffic off primary transaction patterns
- avoid premature microservices unless scale requires it

## Error Handling Rules

- use structured errors
- keep API responses predictable
- distinguish validation, authorization, not-found, and processing-state errors
- fail safely for async workflows

