---
name: architecture-deep-dive
description: Use for system architecture, module boundaries, scalability, search design, AI/RAG design, storage separation, async/event-driven workflows, and platform evolution decisions.
---

# Architecture Deep Dive

Use this skill when the task involves:
- system architecture
- module decomposition
- workflow design
- scalability planning
- search architecture
- vector / RAG architecture
- storage separation
- event-driven processing
- caching strategy
- modular monolith to microservices evolution

## Project Architecture Baseline

This platform is a restricted collaboration and legal knowledge platform for ICA members.

Core capabilities:
- legal knowledge repository
- expert Q&A
- curated news
- AI-assisted search and knowledge discovery

Core principle:
See **CLAUDE.md → Principles** for cross-cutting AI and moderation constraints.

## Core Architecture

### Transaction System
Use PostgreSQL as the source of truth for:
- users
- organizations
- roles
- documents metadata
- questions
- answers
- moderation state
- notifications metadata

### Search System
Use **OpenSearch** as the unified search backend for both keyword and semantic search.
OpenSearch's k-NN plugin provides approximate nearest-neighbour search over dense vectors in the same index as BM25 text fields, enabling hybrid scoring in a single query.

There is no separate vector database. OpenSearch k-NN IS the vector store.

Hybrid search pattern (reciprocal rank fusion):
- BM25 query on text fields (keyword relevance)
- k-NN query on `content_vector` field (semantic similarity)
- Merge via reciprocal rank fusion (k=60), truncate to page_size

One index per content type: `ica_documents`, `ica_questions`, `ica_news`

Searchable content:
- document chunks (OCR-extracted, 512-token chunks with 64-token overlap)
- approved questions + answer summaries (embedded as Q&A pairs)
- news items
- knowledge articles (promoted Q&A)

### AI / Semantic Layer
Embed:
- document chunks (post-approval, via `embedding_generation_job`)
- approved Q&A pairs (via `qa_embedding_job`)
- knowledge articles

Guidelines:
- do not embed everything — only approved, moderated content
- prioritize high-value, reusable knowledge
- optimize for quality and cost
- embedding model: `all-MiniLM-L6-v2` (dev) / `text-embedding-3-small` (prod), controlled by `EMBEDDING_PROVIDER` env var
- batch size: 32 chunks per Celery job

### Document Retraction
Documents have a `law_status` field: `active` | `retracted` | `superseded`.
- Default search returns only `active` documents
- Retracted documents are excluded from default search; require `?status=retracted`
- Retraction is a moderation action: updates PostgreSQL + OpenSearch partial update + Redis cache invalidation
- Superseded documents link to their replacement document

### Object Storage
Use S3 / Blob / MinIO for:
- PDFs
- attachments
- uploaded assets

### Cache / Queue
[THIS IS THE CANONICAL LOCATION FOR CACHE SLOT DEFINITIONS]

Use **two dedicated Redis instances** — never co-host or cross-connect:

**`redis-broker`** (Celery broker — Multi-AZ HA, RTO <60s):
- **db=0** — Celery job queues only (`default` · `ingestion` · `embeddings` · `ai`); no cache data ever

**`redis-cache`** (Application cache — `allkeys-lru` eviction; self-healing single instance):
- **db=0** — Search result cache (`search:{sha256(canonical_params)}`, TTL 300s; invalidated on content approval/retraction); rate limiter counters; unread notification counts (`unread:{user_id}`, TTL 60s)
- **db=1** — Translation cache (`trans:{lang}:{sha256(query)}`, TTL 7d; `_UNAVAILABLE` sentinel cached 1h on translation provider outage)

Do not mix data across Redis instances or DB slots.

### Event / Async Layer
Use Redis queue + Celery for MVP.

Use the **transactional outbox pattern** — full implementation spec in **backend-patterns skill**. Kafka / Redpanda can be introduced later for scale.

Use async/event-driven flows for:
- indexing
- embedding generation
- OCR processing
- notifications
- heavy AI processing

## Architecture Principles

### Separation of concerns
Always separate:
- transactional data
- search data
- AI/vector data
- file/object storage

### Search rule
Do not overload PostgreSQL with search-heavy workloads.

### Vector rule
Do not use vector DB as a general-purpose application database.

### Scaling rule
Start as a modular monolith.
Split into services only when justified by scale, ownership, or performance isolation.

### AI rule
AI should improve discovery, summarization, and assistance.
AI should not replace experts in legal decision-making.

## Preferred Patterns

### CQRS-lite
- writes go to PostgreSQL
- search/read discovery goes to OpenSearch

### Hybrid search
Combine:
- keyword search
- semantic retrieval
- ranking / blending logic

### Event-driven processing
A typical pattern:
1. user action writes to PostgreSQL
2. async event is emitted
3. background workers update search, vector, and notifications

## Canonical Workflows

### Document upload pipeline
Upload → moderation review → approval → OCR → chunk (512 tokens, 64 overlap) → embedding (batch 32) → OpenSearch index (BM25 fields + k-NN vector)

### Q&A flow
Question → moderation → approval → AI suggestion generated → expert answer posted → answer approval → Q&A pair embedded → indexed in OpenSearch `ica_questions`

### Knowledge article promotion
Moderator/Admin selects approved Q&A pair → promotes to Knowledge Article → `qa_embedding_job` indexes into OpenSearch → visible in `/knowledge`

### News flow
Submit → moderation review → approval → OpenSearch index → notify subscribers

### Document retraction flow
Moderator retracts approved document → `law_status = retracted` in PostgreSQL → partial update in OpenSearch (no re-embed) → `search_cache_invalidate_job` purges Redis db=1 keys for affected country/category scope → contributor notified

### Non-English search flow
Member submits query → `langdetect` detects language → check Redis db=2 translation cache → MISS: translate to English via `query_translation_cache_job`, cache result → run OpenSearch hybrid search → return results

### Transactional outbox dispatch
Any state change (approval, rejection, retraction) → write `outbox_events` row atomically in same PostgreSQL transaction → outbox polling worker (Celery beat, every 5s) reads PENDING events → dispatches to Celery queue → marks PUBLISHED or FAILED (DEAD_LETTER after 5 retries)

## Scalability Thresholds

- < 50k doc chunks: single-node OpenSearch, 1 shard, Docker Compose
- 50k–500k chunks: increase heap to 4GB, add 1 replica shard
- > 500k chunks: 3-node cluster, split indices by region (`ica_documents_africa`, etc.)
- Redis cache > 2GB: enable `allkeys-lru`, separate search cache to its own Redis instance

## When giving architecture advice

Always:
- explain tradeoffs
- recommend simplest viable design first
- avoid over-engineering early
- preserve moderation as a first-class concern
- preserve human review for legal interpretation
- optimize AI usage for cost and relevance

## Output Style

When asked for architecture output, prefer:
- module breakdown
- component interaction list
- sequence/workflow steps
- deployment evolution plan
- risks / tradeoffs / recommendations