#!/bin/bash
# TypeScript LSP diagnostics hook
# Runs tsc --noEmit after every Edit/Write on a .ts/.tsx file.
# Exits 2 (asyncRewake) when errors are found so Claude is forced to address them.

INPUT=$(cat)

# jq is required to parse the tool input — skip silently if unavailable
if ! command -v jq &>/dev/null; then
  exit 0
fi

FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null)

# Only process TypeScript files
if [[ ! "$FILE" =~ \.(ts|tsx)$ ]]; then
  exit 0
fi

# Resolve frontend dir relative to project root (CWD when hook runs)
FRONTEND_DIR="./frontend"
if [ ! -d "$FRONTEND_DIR" ]; then
  exit 0
fi

# Capture output into variable first so we preserve tsc's exit code
DIAG=$(cd "$FRONTEND_DIR" && npx tsc --noEmit --pretty false 2>&1)
TSC_EXIT=$?

if [ $TSC_EXIT -eq 0 ]; then
  exit 0
fi

# Truncate to 50 lines and surface the errors
DIAG_TRIMMED=$(echo "$DIAG" | head -50)
echo "TypeScript errors detected after editing: $FILE"
echo ""
echo "$DIAG_TRIMMED"
exit 2
