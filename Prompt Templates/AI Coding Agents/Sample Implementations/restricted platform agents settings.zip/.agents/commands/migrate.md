# /migrate

Generate and apply an Alembic migration.

## Argument
Pass migration name: `/migrate <name>`

## Instructions

1. Check current migration state:

   ```bash
   cd backend && alembic current
   ```

2. Generate the migration:

   ```bash
   cd backend && alembic revision --autogenerate -m "$ARGUMENT"
   ```

3. Review the generated file in `backend/alembic/versions/` before applying:
   - Confirm upgrade creates only expected objects.
   - Confirm downgrade reverses the change safely when possible.
   - Confirm tenant/platform schema rules if the changed model uses schema separation.
   - Confirm no destructive data loss unless explicitly requested.

4. Apply:

   ```bash
   cd backend && alembic upgrade head
   ```

5. Verify:

   ```bash
   cd backend && alembic current
   ```

6. If migration fails, do not edit the database manually. Fix the model/migration and rerun the migration workflow.
