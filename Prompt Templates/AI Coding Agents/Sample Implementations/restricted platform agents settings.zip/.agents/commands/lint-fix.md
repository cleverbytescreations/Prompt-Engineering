# /lint-fix

Run linting and type checks, then fix all issues found.

## Instructions

1. Run frontend lint and type checks:

   ```bash
   cd frontend && npm run lint
   cd frontend && npx tsc --noEmit --pretty false
   ```

2. Run backend tests as the current backend quality gate:

   ```bash
   cd backend && pytest
   ```

3. Fix issues manually:
   - Use LSP hover/type info before adding annotations or changing signatures.
   - Prefer the project's established patterns over broad rewrites.
   - Do not suppress warnings with ignore comments unless there is a documented reason.

4. Confirm clean with the same commands.

5. Report the count fixed and any remaining issue with file:line.
