# /impl-phase

Implement the next incomplete phase of ICA Restricted Legal Platform, following the project checklist exactly.

## Argument
Pass the phase number and area: `/impl-phase 1 api` or `/impl-phase 1 ui`
If no argument is given, detect the next incomplete phase from `Docs/PHASE_*_API_TASK_CHECKLIST.md` and `Docs/PHASE_*_UI_TASK_CHECKLIST.md`.

## Instructions

### Step 1 - Scope
Read only the relevant phase checklist section from `Docs/PHASE_<N>_API_TASK_CHECKLIST.md` or `Docs/PHASE_<N>_UI_TASK_CHECKLIST.md`. Use `AGENTS.md` and applicable `.agents/skills/*` files for architecture and coding rules.

### Step 2 - Navigate with symbols first
- Use LSP definition/references for models, schemas, services, endpoints, components, hooks, and shared utilities.
- Use targeted file reads only for known sections.
- Avoid broad searches except for config strings, comments, TODOs, or non-symbol literals.

### Step 3 - Implementation order
For backend feature phases:
1. Models/entities -> `backend/app/models/*.py`
2. Migration -> `backend/alembic/versions/*.py`
3. Schemas/DTOs -> `backend/app/schemas/*.py`
4. Repository/data-access -> `backend/app/repositories/*_repo.py`
5. Service/business logic -> `backend/app/services/*_service.py`
6. Endpoint/controller/router -> `backend/app/api/v1/*.py`
7. Router registration in `backend/app/main.py` or `backend/app/api/v1/__init__.py` if needed
8. Workers/tasks under the backend worker module when introduced by the phase

For frontend phases, stay inside `frontend/` and follow `frontend-guidelines`.

### Step 4 - Quality gates
Run after meaningful edit groups:

```bash
cd frontend && npm run lint
cd frontend && npx tsc --noEmit --pretty false
cd backend && pytest
```

### Step 5 - Update checklist
Mark verified completed items `[x]` in the relevant `Docs/PHASE_*_TASK_CHECKLIST.md` file and preserve its existing status/progress format.

## Safety rules
- Do not re-read files you just edited.
- Batch related edits where safe.
- Stop before destructive database or filesystem operations.
