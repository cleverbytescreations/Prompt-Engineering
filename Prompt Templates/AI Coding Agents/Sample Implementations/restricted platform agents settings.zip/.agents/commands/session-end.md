# /session-end

Wrap up the session: verify work, update checklist, and prepare a commit if requested.

## Argument
Optional phase number and area: `/session-end 1 api`

## Instructions

1. Check status:

   ```bash
   git status
   ```

2. Verify relevant checks:

   ```bash
   cd frontend && npm run lint
   cd frontend && npx tsc --noEmit --pretty false
   cd backend && pytest
   ```

3. Do not commit if required checks are red.

4. Update checklist:
   Run `/update-checklist <phase> <api|ui>` when a phase is known.

5. If the user asked to commit, stage only relevant project files:

   ```bash
   git add backend frontend Docs/PHASE_*_TASK_CHECKLIST.md AGENTS.md .agents
   git commit -m "Phase <N>: <summary>"
   ```

6. Session summary:
   - Files changed
   - Checks run and result
   - Checklist updates
   - Remaining risks or next task
