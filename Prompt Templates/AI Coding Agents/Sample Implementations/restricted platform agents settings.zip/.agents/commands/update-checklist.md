# /update-checklist

Verify and mark completed tasks in the checklist.

## Argument
Pass phase and area: `/update-checklist 1 api` or `/update-checklist 1 ui`

## Instructions

1. Read only the relevant checklist file:
   - API: `Docs/PHASE_<N>_API_TASK_CHECKLIST.md`
   - UI: `Docs/PHASE_<N>_UI_TASK_CHECKLIST.md`
2. For each unchecked backend task, verify completion through code evidence:
   - Models/entities exist in `backend/app/models/*.py`
   - Schemas/DTOs exist in `backend/app/schemas/*.py`
   - Repository/data-access functions exist in `backend/app/repositories/*_repo.py`
   - Services/functions exist in `backend/app/services/*_service.py`
   - Service files do not contain raw SQLAlchemy query construction such as `select()`, `insert()`, `update()`, `delete()`, joins, filters, ordering, or pagination
   - Endpoints/routes exist in `backend/app/api/v1/*.py`
   - Tests exist or pass when the task requires tests
3. For each unchecked UI task, verify completion in `frontend/app/`, `frontend/components/`, `frontend/hooks/`, `frontend/lib/`, `frontend/store/`, `frontend/types/`, `frontend/mocks/`, or `frontend/messages/`.
4. Mark only verified items `[x]`; leave uncertain items unchecked.
5. If all tasks in a phase are complete, update phase status and completion date using the checklist's existing format.
6. Update any overall progress table using the checklist's existing format.

## Token rule
Read only the relevant checklist section unless the progress table must be updated.
