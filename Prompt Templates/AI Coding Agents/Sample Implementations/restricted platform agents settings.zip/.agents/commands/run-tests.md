# /run-tests

Run the project's detected test and quality gates.

## Instructions

This repo has no root Docker Compose file, so use host/in-project commands.

1. Backend tests:

   ```bash
   cd backend && pytest
   ```

2. Frontend lint:

   ```bash
   cd frontend && npm run lint
   ```

3. Frontend type check:

   ```bash
   cd frontend && npx tsc --noEmit --pretty false
   ```

4. For failing tests, rerun the specific failing test first in the same mode:

   ```bash
   cd backend && pytest tests/<test_file.py>::<test_name>
   ```

5. Rerun the full relevant suite after fixes.
