# /phase-status

Show the current phase and exact next tasks.

## Instructions

1. Read the requested phase checklist, or find the first incomplete file among `Docs/PHASE_*_API_TASK_CHECKLIST.md` and `Docs/PHASE_*_UI_TASK_CHECKLIST.md`.
2. Focus on the first incomplete phase or the phase requested by the user.
3. List unchecked `[ ]` items grouped by section.
4. Identify which work can run in parallel and which work is sequential.
5. Output a prioritized work order.

## Constraints
- Do not implement anything.
- Keep output under 40 lines.
- Include file/path references only when they are present in the checklist or obvious from the project structure.
