# /new-endpoint

Scaffold a new API endpoint following the ICA Restricted Legal Platform backend pattern.

## Argument
`/new-endpoint <domain> <verb> <resource>`

## Instructions

1. Find the nearest existing endpoint in `backend/app/api/v1/*.py` for the same style.
2. Use LSP definition/references to confirm imports, dependency injection, auth, routing, and response patterns.
3. Add or update schema/DTO types in `backend/app/schemas/*.py`.
4. Add repository/data-access functions in `backend/app/repositories/*_repo.py`.
5. Add service/business logic in `backend/app/services/*_service.py` that calls repositories and does not construct raw SQLAlchemy queries.
6. Add route/controller code in `backend/app/api/v1/*.py`.
7. Register the route if the project requires explicit registration.
8. Add or update focused tests in `backend/tests/`.
9. Run:

   ```bash
   cd backend && pytest <specific_endpoint_test_if_available>
   ```

## Constraints
- Enforce the project's authentication and authorization dependency pattern.
- Preserve organisation/user scoping rules when applicable.
- Do not put business logic directly in route handlers.
- Report only the schema, repository, service, route, and test locations changed.
