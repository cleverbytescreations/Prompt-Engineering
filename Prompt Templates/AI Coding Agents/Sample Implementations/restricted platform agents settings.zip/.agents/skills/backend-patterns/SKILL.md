---
name: backend-patterns
description: Use for FastAPI backend design, clean architecture, services, repositories, async workflows, queues, caching, AI/document pipelines, and scalable backend implementation.
---

# Backend Patterns

Use this skill when the task involves:
- FastAPI module design or endpoint implementation
- service/repository/model boundaries
- SQLAlchemy, Alembic, PostgreSQL, or transaction design
- Celery, Redis, async workflows, search indexing, AI, or document processing
- API contracts, auth, RBAC, audit, and integration patterns

## Backend Baseline

Preferred stack:
- FastAPI on Python 3.11+ / planned 3.12+
- SQLAlchemy 2.0 async + Alembic
- Pydantic v2 and `pydantic-settings`
- custom OAuth2/JWT with RS256 access/refresh tokens
- slowapi for Redis-backed rate limiting
- Redis split into broker/cache instances
- Celery 5 workers and Redbeat scheduler
- OpenSearch client, boto3/MinIO, pytest/pytest-asyncio

## Backend Architecture Rule

Use clean layering:
1. API layer - `backend/app/api/v1/*.py` - HTTP concerns only: parse request, enforce dependencies, call service, return response
2. Service layer - `backend/app/services/*_service.py` - business logic, orchestration, transaction/session coordination, side effects
3. Repository/data-access layer - `backend/app/repositories/*_repo.py` - SQLAlchemy query construction; receives `AsyncSession`; returns ORM models, rows, or scalar values
4. Model/data layer - `backend/app/models/*.py` - ORM definitions only

API -> Service -> Repository -> Model. Services own sessions and pass `db` into repository functions. Do not put SQLAlchemy `select()`, `insert()`, `update()`, `delete()`, joins, filters, ordering, or pagination logic in service or endpoint files.

## API Design Rules
- Use typed Pydantic request/response schemas from `backend/app/schemas/*.py`.
- Keep auth and role checks explicit through FastAPI dependencies.
- Do not leak ORM models as public API contracts.
- Keep command endpoints separate from search/discovery endpoints where practical.
- Include predictable structured errors for validation, auth, not-found, conflict, and processing-state failures.

## Service Layer Rules
- Services own platform/tenant session boundaries and transactions.
- For tenant-scoped work, use the project's tenant-aware session helper when present; otherwise use the established `AsyncSession` dependency pattern from nearby services.
- Services pass `db: AsyncSession` into repository functions.
- Services may call repositories from multiple domains within one session for cross-domain orchestration.
- Services own business rules, validation, workflow transitions, cost calculations, side effects, outbox writes, and API error translation.
- Services must not contain SQLAlchemy query construction such as `select()`, `insert()`, `update()`, `delete()`, joins, filters, ordering, or pagination.

## Repository Layer Rules
- Use one repository/data-access file per domain under `backend/app/repositories/`.
- All repository functions are `async def` and accept `db: AsyncSession` as the first parameter.
- Repositories own query construction, execution, joins, filters, ordering, pagination, aggregates, eager loading, and persistence helpers.
- Repositories contain no business logic, workflow transitions, authorization decisions, Celery enqueueing, or HTTP concerns.
- Repositories must not raise `HTTPException`; return `None`, return empty collections, or raise domain/database errors for the service to translate.
- Repositories are stateless; prefer module-level functions unless the existing domain uses a thin class.
- Sessions are opened by services/dependencies, never inside repository functions.
- Use `selectinload` or `joinedload` in repositories when response assembly would otherwise cause N+1 queries.

Canonical signatures:

```python
async def get_by_id(db: AsyncSession, entity_id: UUID) -> Model | None: ...
async def list_with_filters(db: AsyncSession, filters: FilterSchema) -> list[Model]: ...
async def create(db: AsyncSession, data: dict) -> Model: ...
async def update(db: AsyncSession, entity: Model, changes: dict) -> Model: ...
async def delete(db: AsyncSession, entity_id: UUID) -> None: ...
```

## Async / Background Rules

Use background workers for:
- Docling OCR/extraction and chunking
- embedding generation and OpenSearch bulk indexing
- notification fanout and unread-count invalidation
- search/entity cache invalidation
- translation, AI RAG, summarisation, and content pre-screening
- exports and other long-running jobs

Do not block request/response cycles with heavy work.

Typical pattern:
1. Accept request
2. Persist initial state and outbox event in one transaction
3. Let outbox poller dispatch Celery work
4. Return status or job-tracking response

## Redis Rules

Do not treat Redis as the system of record. Cache values must be derivable from PostgreSQL, OpenSearch, or object storage.

Use pipelines/batched deletes for invalidation and stampede protection for hot entity cache fills. Avoid unbounded key scans in request paths.

### Redis DB Slot Strategy
See `architecture-deep-dive -> Cache / Queue` for canonical Redis instance, DB slot, key, TTL, and eviction assignments.

## Search / AI Integration Rules

Backend services orchestrate search and AI work through explicit services and workers. See `architecture-deep-dive` for the canonical search/vector storage rule.

Search implementation must:
- query OpenSearch for member discovery
- apply country/category/status filters as OpenSearch filters, not post-filtered Python lists
- use cache keys derived from all query parameters
- invalidate search/entity caches from outbox-driven jobs after OpenSearch refresh when ordering matters
- keep PII out of OpenSearch indices

### Search Cache Service
Use `search:{sha256(all_query_params)}` for approved non-personalized search results, TTL 300s. Track invalidation scopes with Redis sets so updates delete only affected keys. Do not use keyspace-wide scans for invalidation.

## OCR / AI Workflow Rules

Project-specific upload flow:
1. API creates metadata and stores upload reference
2. Asset is written to MinIO/S3 by direct signed upload
3. Moderation decides eligibility
4. Outbox dispatches ingestion
5. Docling extracts text with timeout guard
6. Chunks are generated, embedded, and bulk indexed
7. AI/RAG uses only approved indexed material

AI and OCR outputs must be traceable and reviewable. AI audit logs have a limited TTL as defined by the architecture.

## Transactional Outbox Pattern

This is the canonical location for the full outbox spec.

All domain events for approval, rejection, retraction, indexing, embedding, notifications, cache invalidation, AI audit, exports, and workflow transitions must:
1. Write an `outbox_events` row in the same PostgreSQL transaction as the state change
2. Store only identifiers and state-change metadata in payloads; no entity bodies, chunk text, PDF bytes, or binary data
3. Keep payloads under 4KB, enforced by a shared Pydantic payload validator
4. Assign a documented priority when the service writes the row
5. Never dispatch queue jobs directly from the API handler instead of the outbox

Outbox lifecycle:
`PENDING -> IN_PROGRESS -> PUBLISHED -> archived` or `PENDING -> IN_PROGRESS -> FAILED -> DEAD_LETTER`.

Outbox polling worker:
- lives under the backend worker/task module when implemented, with Celery Beat/Redbeat schedule every 5 seconds
- selects `PENDING` events ordered by `(priority, created_at)` with `FOR UPDATE SKIP LOCKED`
- immediately marks claimed rows `IN_PROGRESS`
- dispatches Celery with `task_id=str(outbox_event.id)` for idempotency
- marks `PUBLISHED` on successful dispatch/completion policy, or `FAILED` with retry metadata
- moves to `DEAD_LETTER` after the configured retry ceiling

Required hot-path index:
`outbox_events(status, priority, created_at)`.

Reliability jobs:
- `outbox_stuck_recovery_job` every 10 minutes resets `IN_PROGRESS` rows older than 10 minutes to `PENDING`
- `outbox_cleanup_job` nightly deletes or archives old `PUBLISHED` and acknowledged `DEAD_LETTER` rows after the retention window

Celery reliability baseline:
- `CELERY_TASK_ACKS_LATE=True`
- `CELERY_TASK_REJECT_ON_WORKER_LOST=True`
- `CELERY_TASK_IGNORE_RESULT=True`
- no Redis result backend
- `visibility_timeout=3600`
- queue-specific time limits and `worker_prefetch_multiplier=1` for long-running queues

## Security Rules
- Enforce JWT auth and RBAC on every protected route.
- JWT payload includes user, role, and organisation context; role escalation must be impossible client-side.
- Enforce organisation scoping in services and repositories.
- Audit sensitive operations and moderation decisions.
- Store PII only where the data model allows it; never index email/name fields into OpenSearch.
- Use anonymisation rather than hard delete for GDPR user deletion when contributions must remain.

## Performance Rules
- Use async I/O for database, Redis, OpenSearch, and HTTP clients.
- Batch expensive work, especially embeddings, notifications, and OpenSearch indexing.
- Use cursor/keyset pagination for feeds and moderation queues.
- Keep analytics off the primary write database when the read replica is available and healthy.
- Keep API request bodies bounded; large files go through object storage.

## Error Handling Rules
- Translate repository/domain failures into structured API errors at the service/API boundary.
- Async failures must leave durable state for retry or operator action.
- Do not manually edit the database to recover failed migrations or outbox events unless explicitly instructed.
- Expose processing state clearly rather than hiding pending/failure states from callers.
