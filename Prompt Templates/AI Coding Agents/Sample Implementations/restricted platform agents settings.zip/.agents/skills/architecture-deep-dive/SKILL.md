---
name: architecture-deep-dive
description: Use for system architecture, module boundaries, scalability, search design, AI/RAG design, storage separation, async/event-driven workflows, and platform evolution decisions.
---

# Architecture Deep Dive

Use this skill when the task involves:
- architecture, module boundaries, or service extraction
- search, OpenSearch mappings, RAG, embeddings, or ranking
- storage, Redis, queues, caching, scalability, or async workflows

## Project Architecture Baseline

ICA Restricted Legal Platform is a moderation-first legal knowledge and collaboration platform for ICA staff, legal professionals, moderators, and member organisations.

Core capabilities:
- governed legal document repository
- expert Q&A and moderated member collaboration
- curated legal news
- hybrid keyword + semantic search
- AI-assisted discovery and review workflows

Core principle:
See `AGENTS.md -> Principles` for cross-cutting constraints.

## Core Architecture

### Transaction System
Use PostgreSQL as the source of truth for:
- users, organisations, roles, invitations, revoked tokens
- document metadata, versions, moderation state, Q&A, news, posts
- notifications, audit trails, outbox events, configuration, analytics aggregates

PostgreSQL writes go through FastAPI services and repositories. PgBouncer is part of the deployment path; API traffic uses pooled PostgreSQL connections and Celery workers should use `NullPool`.

### Search System
OpenSearch 2.x is the only member-facing search surface. PostgreSQL must not serve member-facing full-text discovery paths.

OpenSearch owns both keyword and vector retrieval: BM25 text search plus k-NN vector fields in the same cluster. There is no separate vector database in the current architecture; vectors are stored in OpenSearch index mappings.

Canonical indices:
- `ica_documents` - document-level search and related-document retrieval
- `ica_document_chunks` - chunk-level retrieval for RAG and document search
- `ica_questions` - approved Q&A pairs
- `ica_news` - approved news articles
- `ica_posts` - approved social posts

Index rules:
- Use `country` and `category` as `keyword` pre-filter fields.
- Use `law_status` as a `keyword` filter for documents and chunks; default member search excludes retracted/superseded content.
- Use analysed text fields for title/body/content/answer summaries.
- Use 384-dimensional vectors for local `all-MiniLM-L6-v2` embeddings unless an explicit model migration is underway.
- Use OpenSearch Bulk API for indexing jobs, rollover aliases/ISM for growing indices, and an `800ms` query timeout.

### AI / Semantic Layer
Embed approved reusable knowledge only:
- document chunks after approval and successful Docling extraction
- approved Q&A pairs
- approved high-value news/posts when the implementation plan calls for them

Do not embed draft, rejected, private, PII-heavy, or low-value transient content. Phase 2 RAG uses LangGraph inside Celery `ai` workers with intent classification, multi-source retrieval, reciprocal-rank fusion, confidence scoring, LLM generation, and audit logging. Low-confidence AI output routes to expert review.

### Document / Content Lifecycle
Member-generated content starts as `pending`. Moderator outcomes include approve, reject, request changes, flag, and retract where supported. Admin-originated official content may bypass member moderation only where the architecture explicitly allows it.

Document flow:
Upload metadata + direct S3/MinIO asset -> moderation -> Docling OCR/extraction -> chunk -> embed -> OpenSearch index -> cache invalidation.

If Docling fails on an approved uploaded document, the architecture rejects it automatically as an extraction failure and creates no OpenSearch entry.

### Object Storage
Use MinIO in development and S3-compatible object storage in production for:
- uploaded PDFs and attachments
- export archives
- LiveKit recordings in Phase 3
- generated artefacts that should not live in PostgreSQL

Use direct signed PUT uploads for large files. Store metadata and lifecycle state in PostgreSQL, never binary payloads.

### Cache / Queue
This is the canonical location for Redis instance and DB slot definitions.

Use two separate Redis instances:
- `redis-broker`, `db=0` - Celery broker only; Multi-AZ in production; no result backend; `visibility_timeout=3600`; never co-host cache data here.
- `redis-cache`, `db=0` - search cache, entity cache, revoked-token cache, rate limiting, unread counters, platform config, replica lag, cache invalidation sets; `allkeys-lru`; common keys include `search:{sha256}` TTL 300s, `entity:{type}:{id}`, `revoked:{jti}` TTL remaining token lifetime, `unread:{user_id}` TTL 60s, `config:platform` TTL 60s.
- `redis-cache`, `db=1` - translation cache; `trans:{lang}:{sha256}` TTL 7d; outage sentinel values may cache `_UNAVAILABLE` for 1h.

Do not mix data across instances or slots. Broker and cache are never co-hosted.

### Event / Async Layer
Use the transactional outbox pattern. Full implementation spec lives in `backend-patterns`.

Use Celery 5 with queues:
- `default` - notifications, cache invalidation, search indexing, short I/O work
- `ingestion` - Docling extraction and chunking
- `embeddings` - embedding generation and bulk indexing
- `ai` - RAG, content flagging, summarisation

Use Celery chains where ordering matters, especially `search_index_job -> opensearch_refresh_job -> search_cache_invalidate_job`.

## Architecture Principles

### CQRS-lite
State mutations go to PostgreSQL. Discovery and search reads go to OpenSearch so transactional storage is not overloaded.

### Storage Separation
Metadata belongs in PostgreSQL, binary files in MinIO/S3, indexed content and vectors in OpenSearch, cache data in `redis-cache`, and queue transport in `redis-broker`.

### Moderation-First Scaling
Scale ingestion, indexing, and AI around moderation gates. Approved state is the boundary for search and semantic indexing.

### Progressive Complexity
Start as a modular monolith. Extract SearchService, AIService, or notification services only when scale, ownership, or isolation requires it.

## Preferred Patterns

### Hybrid Search
Combine BM25 and k-NN retrieval with filters, timeout budgets, RRF/ranking, and search-cache invalidation by scope.

### Event-Driven Processing
Write state and outbox event in one PostgreSQL transaction, dispatch through Celery, then update OpenSearch/Redis/object storage asynchronously.

### Zero-Downtime Schema Change
Use expand-contract migrations for live tables: add nullable/backfilled columns first, dual-write/read-compatible code second, enforce constraints later.

## Canonical Workflows

### Document Upload Pipeline
Direct upload -> metadata write -> moderation -> outbox event -> Docling -> chunk -> embed -> OpenSearch bulk index -> refresh -> cache invalidation.

### Q&A Flow
Question -> moderation -> publish -> expert answer -> approval/verification -> notification -> OpenSearch indexing -> optional Phase 2 embedding/RAG use.

### Search Flow
Request -> `redis-cache` search cache -> language detection/translation cache if needed -> OpenSearch hybrid query -> response with filters, labels, and law status.

## Scalability Thresholds
- Search p95 > 800ms inside OpenSearch: inspect filters, mappings, cache hit rate, shard sizing, and query plan before adding infrastructure.
- End-to-end search > 1500ms: check translation/cache misses, OpenSearch timeout, and API serialization.
- Celery queue depth sustained > configured KEDA threshold: scale the queue-specific worker, not the whole monolith.
- Read replica lag > 10s: route analytics/read-only aggregate work back to primary only when the fallback policy permits it; alert at sustained 30s.
- Outbox `IN_PROGRESS` older than 10 minutes: `outbox_stuck_recovery_job` resets it to `PENDING`.

## When Giving Architecture Advice

Always:
- preserve moderation and auditability
- keep storage/search/cache/vector ownership clear
- prefer the simplest deployable design that matches the phase
- name tradeoffs, operational risks, and migration paths
- align recommendations to `Docs/Solution-Architecture-Document.md` and `Docs/implementation-plan.md`

## Output Style
Prefer module breakdowns, component interactions, sequence steps, evolution plans, and risks/tradeoffs/recommendations.
