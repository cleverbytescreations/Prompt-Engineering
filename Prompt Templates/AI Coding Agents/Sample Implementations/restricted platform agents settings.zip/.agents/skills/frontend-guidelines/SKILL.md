---
name: frontend-guidelines
description: Use for all work inside `frontend/`, including Next.js App Router, TypeScript, MUI, Tailwind, React Query, Zustand, forms, mocks, i18n, API contracts, and UI task execution.
---

# Frontend Guidelines

Use this skill when the task involves:
- any file inside `frontend/`
- App Router pages/layouts and route groups
- React components, forms, state, mocks, i18n, API contracts, or UI task execution

## Scope Rules
- All frontend work must stay inside `frontend/`.
- Do not create files outside `frontend/` unless adding or updating root-level docs.
- Use the existing module structure: `app/`, `components/`, `hooks/`, `lib/`, `store/`, `types/`, `mocks/`, `messages/`.
- Do not put business logic in UI; domain decisions belong in backend services.

## Frontend Stack
- Next.js 16 App Router
- React 19
- TypeScript 5
- MUI 9 and Emotion
- Tailwind CSS 4 for layout/spacing utilities
- TanStack React Query 5 for server state
- Zustand 5 for auth/role/light shared UI state
- React Hook Form 7 with Zod 4
- MSW 2 for demo/mock mode
- next-intl 4 for i18n
- TipTap for rich text where already used
- react-pdf/pdfjs-dist for PDF display

## Import Rules
- Use `@/` path alias for imports when available.
- Avoid deep relative imports across module boundaries.
- Keep shared types in `frontend/types/` or beside the owning module when local.

## UI Design Rules
- Prefer MUI for interactive elements such as buttons, inputs, dialogs, chips, tabs, menus, and tables.
- Use Tailwind mainly for page layout, spacing, and small composition utilities.
- Use lucide-react or MUI icons for icon buttons when an icon exists.
- Surface law status, moderation status, AI-assist labels, and role context consistently.
- Do not show unapproved member-generated content in member-facing screens.

## Component Rules
- Use PascalCase component file names.
- One component per file unless a tiny local helper is justified.
- Keep components presentation-focused and typed.
- Move data fetching to React Query hooks or typed API helpers.
- Keep large workflow screens decomposed into local panels/sections rather than nested cards.

## Data Fetching Rules
- API calls go through React Query patterns.
- Prefer typed API client functions in `frontend/lib/api/`.
- Align request/response types with `Docs/implementation-plan.md` and `Docs/API_SPECIFICATION_OPENAPI.md`.
- Read notification badge counts from `X-Notification-Unread-Count` when available; do not poll unread count more often than the architecture permits.

## Forms Rules
- Use React Hook Form with Zod validation.
- Keep validation schemas explicit and typed.
- Surface validation errors clearly and close to the field.
- Preserve backend validation and RBAC as the source of truth; frontend validation is assistive.

## State Rules
- Use Zustand only for auth, role context, preferences, and lightweight shared UI state.
- Do not move server state into Zustand when React Query is the right tool.
- Keep optimistic updates narrow and invalidate the relevant query keys after mutations.

## Mock / Demo Mode Rules
When `NEXT_PUBLIC_DEMO_MODE=true`:
- Use MSW handlers from `frontend/mocks/`.
- Match the real API contract shape.
- Include realistic latency, usually 100-400ms.
- Use realistic ICA legal-platform fixture data.
- Keep mocked moderation/search states aligned with the implementation plan.

## Source of Truth
- `Docs/PHASE_1_UI_TASK_CHECKLIST.md`, `Docs/PHASE_2_UI_TASK_CHECKLIST.md`, `Docs/PHASE_3_UI_TASK_CHECKLIST.md` - UI task checklists
- `Docs/implementation-plan.md` - implementation plan and route/API mapping
- `Docs/API_SPECIFICATION_OPENAPI.md` - API contract reference

## Directory Guidance
- pages/routes -> `frontend/app/`
- reusable UI -> `frontend/components/`
- data hooks -> `frontend/hooks/`
- API helpers -> `frontend/lib/api/`
- global state -> `frontend/store/`
- shared types -> `frontend/types/`
- mocks -> `frontend/mocks/`
- translations -> `frontend/messages/`

## Quality Rules
- Keep TypeScript strict and avoid `any` unless documented.
- Run `npm run lint` from `frontend/` before considering frontend work complete.
- Run `npx tsc --noEmit --pretty false` from `frontend/` after meaningful TypeScript edits.
- Verify responsive layouts for member, moderator, and admin workflows when UI changes are user-facing.

## When Generating Frontend Output
Prefer exact file paths, minimal production-usable code, typed props, reusable patterns aligned to current structure, and short placement explanations.

## Avoid
- Direct backend assumptions not present in the documented contract.
- Business rules hidden in presentation components.
- Ad hoc fetch calls scattered in UI.
- Server-state duplication in Zustand.
- Mock handlers that drift from real response shapes.
