# AGENTS.md

## Project Overview

This project is a restricted social and knowledge collaboration platform for ICA (International Cooperative Alliance) members focused on cooperative law and policy.

Goals:

* Build a centralized legal knowledge repository
* Enable expert-driven Q&A and collaboration
* Provide curated news and updates
* Support AI-assisted legal search and insights

Future Vision:

* Scale to a global public platform (10K → 1M+ users)
* Evolve into a **legal knowledge engine + AI assistant + expert network**

Audience:

* ICA Legal Office (Admins & Moderators)
* ICA Member Organizations (Legal experts, policy advisors)
* (Future) Public users

---

## Tech Stack

### Frontend

* Next.js (React, PWA, App Router)
* TypeScript
* Tailwind CSS / Material UI
* React Query (API state management)

---

### Backend

* FastAPI (Python)
* SQLAlchemy / SQLModel
* Pydantic
* JWT Authentication
* Celery / Background Workers
* Redis (caching + queue for MVP)

---

### Data Layer (Scalable Design)

#### 1. OLTP Database (Source of Truth)

* PostgreSQL
* Stores:

  * Users, Organizations, Roles
  * Questions, Answers
  * Moderation workflows
  * Metadata

---

#### 2. Search Engine (Read-Optimized)

* Elasticsearch / OpenSearch
* Stores:

  * Questions
  * Answers
  * News
  * Posts
* Purpose:

  * Full-text search
  * Filtering (country, category, tags)
  * Ranking & relevance

---

#### 3. Vector Database (AI Layer)

* MVP: FAISS
* Scalable: Weaviate (prefered) / Qdrant / Pinecone
* Stores:

  * Document embeddings (chunks)
  * Approved Q&A embeddings
* Purpose:

  * Semantic search
  * RAG-based AI answers

---

#### 4. Object Storage

* AWS S3 / Azure Blob / MinIO
* Stores:

  * PDFs
  * Attachments
* Use CDN for delivery (CloudFront / equivalent)

---

#### 5. Cache Layer

* Redis
* Used for:

  * API caching
  * AI response caching
  * Session/token caching

---

#### 6. Event Streaming (Scalable Phase)

* Kafka / Redpanda (future)
* Redis Queue (MVP)
* Purpose:

  * Async processing
  * Decoupling services
  * Data pipeline for indexing & AI

---

### AI Layer

* RAG (Retrieval-Augmented Generation)
* Embedding Models:

  * OpenAI / BGE / Instructor models
* LLM:

  * OpenAI / Azure OpenAI / OSS models

Capabilities:

* Semantic search across legal documents
* AI-assisted Q&A
* Document summarization
* Multilingual translation

---

### OCR & Data Processing

* Tesseract (open-source)
* Cloud OCR (AWS Textract / Azure Form Recognizer)

---

## Core Modules

1. User Management & Access Control
2. Knowledge Repository (Legal Database)
3. Question & Answer System
4. News & Updates
5. Social Collaboration (lightweight, professional)
6. Moderation & Validation (critical)
7. Search & Discovery (keyword + semantic)
8. AI Processing & Knowledge Extraction
9. Notification System

---

## Key Workflows

### Document Upload Pipeline

Upload → OCR → Chunking → Metadata → Moderator Review → Publish →
→ Index (Elasticsearch) → Embed (Vector DB)

---

### Q&A Flow

Question → Moderation → Publish →
→ AI Suggestion (RAG) → Expert Answer →
→ Store → Index → Embed → Reusable Knowledge

---

### News Flow

Submit → Review → Publish → Index → Notify users

---

### Data Processing Pipeline (Event-Driven)

User Action → PostgreSQL (write) → Event Queue →
Consumers:

* Search Indexing (Elasticsearch)
* Embedding Generation (Vector DB)
* Notification Service

---

## Architecture Patterns

### 1. CQRS (Command Query Responsibility Segregation)

* Writes → PostgreSQL
* Reads/Search → Elasticsearch

---

### 2. Hybrid Search

* Keyword search (Elasticsearch)
* Semantic search (Vector DB)
* Combined ranking for results

---

### 3. Event-Driven Processing

* Async pipelines for:

  * Indexing
  * Embeddings
  * Notifications

---

### 4. Modular Monolith (MVP) → Microservices (Scale Phase)

* Start simple
* Split services as scale increases

---

## Data Strategy

### Hot Data

* Recent questions
* Active discussions
* Cached in Redis

---

### Cold Data

* Old/archived content
* Stored in S3 / data lake

---

### Partitioning Strategy

* PostgreSQL partitioning (by date/volume)
* Elasticsearch sharding
* Vector DB horizontal scaling

---

## AI Design Principles

* AI is **assistive**, not authoritative
* Human validation is mandatory for legal interpretation
* Only high-value content is embedded (not all posts)
* AI usage must be optimized for cost

---

## Security & Access Control

* Invite-only onboarding (MVP)
* Role-Based Access Control (RBAC):

  * Admin
  * Moderator
  * Member
* Organization-level restrictions
* Data privacy enforcement

---

## Code Conventions

### Frontend

* Use TypeScript
* Component-based architecture
* API layer separated (React Query)
* No business logic in UI

---

### Backend

* Follow clean architecture principles
* Separate:

  * API layer
  * Service layer
  * Repository layer
* Use async wherever possible
* Background jobs for heavy processing

---

## Scalability Guidelines

* Do NOT overload PostgreSQL with search queries
* Do NOT store all data in Vector DB
* Always separate:

  * Transactional data
  * Search data
  * AI data
* Introduce caching early (Redis)
* Use async/event-driven processing

---

## Notes

* Platform is invite-only (initial phase)
* Focus is **knowledge + collaboration**, not social media
* Moderation is a core differentiator
* AI enhances discovery but does not replace experts
* Design must support future public-scale expansion

---
