# ICA Restricted Social Platform — Implementation Plan

## Overview

A restricted, invite-only knowledge collaboration platform for ICA (International Cooperative Alliance) members focused on cooperative law and policy. This plan covers the full MVP build across frontend (Next.js), backend (FastAPI), and infrastructure.

---

## Tech Stack Summary

| Layer          | Technology                                  |
|----------------|---------------------------------------------|
| Frontend       | Next.js (App Router), TypeScript, Tailwind, React Query |
| Backend        | FastAPI (Python), SQLAlchemy, Pydantic, JWT |
| Database       | PostgreSQL                                  |
| Cache / Queue  | Redis                                       |
| Object Storage | MinIO (local) → AWS S3 (production)         |
| AI / RAG       | FAISS (MVP), sentence-transformers / OpenAI |
| Worker         | Celery                                      |
| Email          | SMTP / SendGrid (password reset + notifications) |
| DevOps         | Docker Compose                              |

---

## Phase Plan

| Phase | Scope                                         | Priority |
|-------|-----------------------------------------------|----------|
| 1     | Core MVP: Auth, Q&A, Repository, News, Moderation, Admin | Must-Have |
| 2     | AI Layer: RAG pipeline, semantic search, AI-assisted answers | High |
| 3     | Scale: Multi-language, analytics, recommendations | Future |

---

## Architecture

```
React (Next.js PWA)
        ↓
API Gateway (FastAPI)
        ↓
Modular Service Layer
        ↓
PostgreSQL + MinIO/S3
        ↓
AI Services (RAG pipeline + FAISS/Weaviate)
```

Background pipeline:
```
Upload → OCR → Chunking → Embedding → Vector DB
User Action → PostgreSQL → Redis Queue → Celery Workers
                                      → Search Indexing
                                      → Notification Service
```

---

## Project Structure

```
/
├── frontend/               # Next.js application
│   ├── app/                # App Router pages
│   ├── components/         # Reusable UI components
│   ├── lib/                # API clients, utilities
│   ├── hooks/              # React Query hooks
│   └── store/              # Zustand global state
├── backend/                # FastAPI application
│   ├── app/
│   │   ├── api/            # Route handlers
│   │   ├── services/       # Business logic
│   │   ├── repositories/   # DB access layer
│   │   ├── models/         # SQLAlchemy models
│   │   ├── schemas/        # Pydantic schemas
│   │   ├── workers/        # Celery jobs
│   │   └── core/           # Config, security, deps
│   └── alembic/            # DB migrations
├── Docs/                   # Project documentation
└── docker-compose.yml
```

---

## API Endpoints Reference

All endpoints are prefixed with `/api/v1`. Protected endpoints require `Authorization: Bearer <token>`.

Role abbreviations: **A** = Admin, **M** = Moderator, **U** = Member

---

### Module 1 — Authentication & Onboarding

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/auth/verify-invite`            | Validate invite code               | No     | —     |
| POST   | `/auth/signup`                   | Register with valid invite code    | No     | —     |
| POST   | `/auth/login`                    | Email + password login             | No     | —     |
| POST   | `/auth/logout`                   | Invalidate token / session         | Yes    | A,M,U |
| POST   | `/auth/forgot-password`          | Send password reset email          | No     | —     |
| POST   | `/auth/reset-password`           | Reset password with token          | No     | —     |
| POST   | `/auth/refresh-token`            | Refresh JWT access token           | Yes    | A,M,U |
| GET    | `/auth/me`                       | Get current authenticated user     | Yes    | A,M,U |
| PATCH  | `/auth/me`                       | Update own profile                 | Yes    | A,M,U |
| POST   | `/auth/me/preferences`           | Save interest preferences (setup)  | Yes    | A,M,U |
| POST   | `/auth/me/change-password`       | Change password (authenticated)    | Yes    | A,M,U |

---

### Module 2 — User Management

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| GET    | `/users`                         | List all users (with filters)      | Yes    | A,M   |
| GET    | `/users/{id}`                    | Get user profile                   | Yes    | A,M,U |
| PUT    | `/users/{id}`                    | Update user profile                | Yes    | A     |
| DELETE | `/users/{id}`                    | Delete / deactivate user           | Yes    | A     |
| PATCH  | `/users/{id}/status`             | Activate or deactivate user        | Yes    | A     |
| PATCH  | `/users/{id}/role`               | Assign/change user role            | Yes    | A     |
| GET    | `/users/{id}/contributions`      | User's questions, docs, posts      | Yes    | A,M,U |

---

### Module 3 — Organization Management

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| GET    | `/organizations`                 | List all organizations             | Yes    | A,M,U |
| POST   | `/organizations`                 | Create new organization            | Yes    | A     |
| GET    | `/organizations/{id}`            | Get organization details           | Yes    | A,M,U |
| PUT    | `/organizations/{id}`            | Update organization                | Yes    | A     |
| DELETE | `/organizations/{id}`            | Delete organization                | Yes    | A     |
| GET    | `/organizations/{id}/members`    | List members of organization       | Yes    | A,M   |

---

### Module 4 — Invite Management

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/invites`                       | Generate new invite code           | Yes    | A     |
| GET    | `/invites`                       | List all invites                   | Yes    | A     |
| GET    | `/invites/{code}`                | Get invite details / status        | Yes    | A     |
| DELETE | `/invites/{code}`                | Revoke invite code                 | Yes    | A     |

---

### Module 5 — Knowledge Repository (Documents)

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/documents`                     | Upload document (PDF file or external URL) | Yes    | A,M,U |
| GET    | `/documents`                     | List approved documents (filters)  | Yes    | A,M,U |
| GET    | `/documents/{id}`                | Get document detail + metadata     | Yes    | A,M,U |
| PUT    | `/documents/{id}`                | Update document metadata           | Yes    | A,M   |
| DELETE | `/documents/{id}`                | Delete document                    | Yes    | A     |
| GET    | `/documents/{id}/download`       | Download document file             | Yes    | A,M,U |
| GET    | `/documents/{id}/related`        | AI-powered related documents       | Yes    | A,M,U |
| GET    | `/documents/my`                  | Current user's uploaded documents  | Yes    | A,M,U |
| GET    | `/documents/{id}/status`         | Get upload/moderation status       | Yes    | A,M,U |

---

### Module 6 — Question & Answer

#### Questions

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/questions`                     | Submit a new question              | Yes    | A,M,U |
| GET    | `/questions`                     | List approved questions (filters)  | Yes    | A,M,U |
| GET    | `/questions/{id}`                | Get question detail                | Yes    | A,M,U |
| PUT    | `/questions/{id}`                | Edit question (pre-moderation)     | Yes    | A,M,U |
| DELETE | `/questions/{id}`                | Delete question                    | Yes    | A     |
| GET    | `/questions/my`                  | Current user's questions           | Yes    | A,M,U |

#### Answers

| Method | Endpoint                                   | Description                        | Auth   | Roles |
|--------|--------------------------------------------|------------------------------------|--------|-------|
| POST   | `/questions/{question_id}/answers`         | Post an answer                     | Yes    | A,M,U |
| GET    | `/questions/{question_id}/answers`         | List answers for a question        | Yes    | A,M,U |
| PUT    | `/answers/{id}`                            | Edit an answer                     | Yes    | A,M,U |
| DELETE | `/answers/{id}`                            | Delete an answer                   | Yes    | A     |
| PATCH  | `/answers/{id}/accept`                     | Mark answer as accepted            | Yes    | A,M,U |

---

### Module 7 — News & Updates

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/news`                          | Submit news article                | Yes    | A,M,U |
| GET    | `/news`                          | List approved news (filters)       | Yes    | A,M,U |
| GET    | `/news/{id}`                     | Get news article detail            | Yes    | A,M,U |
| PUT    | `/news/{id}`                     | Update news article                | Yes    | A,M   |
| DELETE | `/news/{id}`                     | Delete news article                | Yes    | A     |
| GET    | `/news/my`                       | Current user's submitted news      | Yes    | A,M,U |

---

### Module 8 — Social Feed / Posts

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| POST   | `/posts`                         | Create a post                      | Yes    | A,M,U |
| GET    | `/posts`                         | List social feed posts             | Yes    | A,M,U |
| GET    | `/posts/{id}`                    | Get post detail                    | Yes    | A,M,U |
| PUT    | `/posts/{id}`                    | Edit post                          | Yes    | A,M,U |
| DELETE | `/posts/{id}`                    | Delete post                        | Yes    | A     |
| POST   | `/posts/{id}/like`               | Like/unlike a post                 | Yes    | A,M,U |
| GET    | `/posts/{id}/comments`           | Get comments on a post             | Yes    | A,M,U |
| POST   | `/posts/{id}/comments`           | Add a comment to a post            | Yes    | A,M,U |
| DELETE | `/posts/{id}/comments/{cid}`     | Delete a comment                   | Yes    | A,M   |

---

### Module 9 — Moderation

| Method | Endpoint                              | Description                             | Auth   | Roles |
|--------|---------------------------------------|-----------------------------------------|--------|-------|
| GET    | `/moderation/queue`                   | Full moderation queue (all types)       | Yes    | A,M   |
| GET    | `/moderation/queue/questions`         | Pending questions queue                 | Yes    | A,M   |
| GET    | `/moderation/queue/documents`         | Pending documents queue                 | Yes    | A,M   |
| GET    | `/moderation/queue/news`              | Pending news queue                      | Yes    | A,M   |
| GET    | `/moderation/queue/posts`             | Pending posts queue                     | Yes    | A,M   |
| POST   | `/moderation/approve`                 | Approve a submission                    | Yes    | A,M   |
| POST   | `/moderation/reject`                  | Reject a submission with remarks        | Yes    | A,M   |
| POST   | `/moderation/request-changes`         | Return for revision with feedback       | Yes    | A,M   |
| GET    | `/moderation/logs`                    | Full moderation audit log               | Yes    | A     |
| GET    | `/moderation/logs/{entity_type}/{id}` | Moderation history for a specific item  | Yes    | A,M   |
| GET    | `/moderation/stats`                   | Moderation queue counts by type         | Yes    | A,M   |

---

### Module 10 — Notifications

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| GET    | `/notifications`                 | List user's notifications          | Yes    | A,M,U |
| GET    | `/notifications/unread-count`    | Get unread notification count      | Yes    | A,M,U |
| PATCH  | `/notifications/{id}/read`       | Mark notification as read          | Yes    | A,M,U |
| PATCH  | `/notifications/read-all`        | Mark all notifications as read     | Yes    | A,M,U |
| DELETE | `/notifications/{id}`            | Delete a notification              | Yes    | A,M,U |

---

### Module 11 — Search & AI

| Method | Endpoint                         | Description                             | Auth   | Roles |
|--------|----------------------------------|-----------------------------------------|--------|-------|
| GET    | `/search`                        | Global keyword search (q, type, filters)| Yes    | A,M,U |
| POST   | `/ai/ask`                        | AI-powered semantic Q&A (RAG)           | Yes    | A,M,U |
| GET    | `/ai/suggestions/{question_id}`  | AI answer suggestion for a question     | Yes    | A,M   |
| POST   | `/ai/summarize/{document_id}`    | AI summary of a document                | Yes    | A,M,U |
| POST   | `/ai/related/{document_id}`      | Find semantically related documents     | Yes    | A,M,U |
| POST   | `/ai/translate`                  | Translate text to a specified language  | Yes    | A,M,U |
| GET    | `/ai/translate/languages`        | List supported translation languages    | Yes    | A,M,U |

---

### Module 12 — Dashboard (Aggregated)

| Method | Endpoint                         | Description                             | Auth   | Roles |
|--------|----------------------------------|-----------------------------------------|--------|-------|
| GET    | `/dashboard`                     | Aggregated: news, questions, docs, notif count | Yes | A,M,U |

---

### Module 13 — Taxonomy / Reference Data

| Method | Endpoint                         | Description                        | Auth   | Roles |
|--------|----------------------------------|------------------------------------|--------|-------|
| GET    | `/tags`                          | List available tags                | Yes    | A,M,U |
| POST   | `/tags`                          | Create new tag                     | Yes    | A     |
| PUT    | `/tags/{id}`                     | Update tag                         | Yes    | A     |
| DELETE | `/tags/{id}`                     | Delete tag                         | Yes    | A     |
| GET    | `/countries`                     | List supported countries           | Yes    | A,M,U |
| GET    | `/categories`                    | List document/question categories  | Yes    | A,M,U |
| POST   | `/categories`                    | Create new category                | Yes    | A     |
| PUT    | `/categories/{id}`               | Update category                    | Yes    | A     |
| DELETE | `/categories/{id}`               | Delete category                    | Yes    | A     |

---

### Module 14 — Admin Statistics

| Method | Endpoint                         | Description                             | Auth   | Roles |
|--------|----------------------------------|-----------------------------------------|--------|-------|
| GET    | `/admin/stats`                   | Platform-wide counts: users (total, by org, by role), content (docs, questions, news, posts), moderation throughput, AI query volume | Yes | A |

---

## Frontend Page → API Mapping

| Route                        | Key APIs Used                                              |
|------------------------------|------------------------------------------------------------|
| `/auth/login`                | POST /auth/login                                           |
| `/auth/signup`               | POST /auth/verify-invite, POST /auth/signup                |
| `/auth/forgot-password`      | POST /auth/forgot-password, POST /auth/reset-password      |
| `/dashboard`                 | GET /dashboard, GET /notifications/unread-count            |
| `/repository`                | GET /documents, GET /countries, GET /categories, GET /tags |
| `/repository/[id]`           | GET /documents/{id}, GET /documents/{id}/related           |
| `/repository/upload`         | POST /documents                                            |
| `/questions`                 | GET /questions, GET /countries, GET /categories            |
| `/questions/ask`             | POST /questions, GET /tags                                 |
| `/questions/[id]`            | GET /questions/{id}, GET /questions/{id}/answers, POST /questions/{id}/answers, GET /ai/suggestions/{id} |
| `/questions/my`              | GET /questions/my                                          |
| `/news`                      | GET /news                                                  |
| `/news/[id]`                 | GET /news/{id}                                             |
| `/news/create`               | POST /news                                                 |
| `/news/my`                   | GET /news/my                                               |
| `/feed`                      | GET /posts                                                 |
| `/post/create`               | POST /posts                                                |
| `/notifications`             | GET /notifications, PATCH /notifications/read-all          |
| `/search`                    | GET /search, POST /ai/ask                                  |
| `/moderation`                | GET /moderation/queue, GET /moderation/stats               |
| `/moderation/questions`      | GET /moderation/queue/questions, POST /moderation/approve, POST /moderation/reject |
| `/moderation/documents`      | GET /moderation/queue/documents, POST /moderation/approve, POST /moderation/reject |
| `/moderation/news`           | GET /moderation/queue/news, POST /moderation/approve, POST /moderation/reject |
| `/admin/users`               | GET /users, PATCH /users/{id}/status, PATCH /users/{id}/role |
| `/admin/orgs`                | GET /organizations, POST /organizations, PUT /organizations/{id} |
| `/admin/invites`             | POST /invites, GET /invites, DELETE /invites/{code}        |
| `/admin/analytics`           | GET /admin/stats, GET /moderation/stats                    |
| `/profile/[id]`              | GET /users/{id}, GET /users/{id}/contributions             |

---

## Background Jobs (Celery Workers)

| Job Name                    | Trigger                        | Description                                   |
|-----------------------------|--------------------------------|-----------------------------------------------|
| `document_ingestion_job`    | On document upload approved    | OCR extraction from PDF                       |
| `chunking_job`              | After OCR completion           | Split document into semantic chunks           |
| `embedding_generation_job`  | After chunking                 | Generate vector embeddings for doc chunks, store in FAISS |
| `qa_embedding_job`          | On Q&A pair approved           | Embed approved question+answer pair into FAISS index      |
| `ai_answer_job`             | On POST /ai/ask                | RAG retrieval + LLM answer generation                     |
| `ai_content_flag_job`       | On content submission          | AI pre-screen for inappropriate/off-topic content         |
| `translation_job`           | On AI query / content request  | Translate input to English for processing, output back    |
| `notification_dispatch_job` | On content status change       | Create in-app notifications for relevant users            |
| `search_index_job`          | On content approval            | Index content in search layer                             |

---

## Key Design Decisions

1. **CQRS**: Writes → PostgreSQL; Reads/Search → application-level query with future Elasticsearch migration path.
2. **Moderation-first**: All user-generated content (questions, documents, news, posts) enters a pending state and must be approved before appearing publicly. Three outcomes: Approve, Reject, Request Changes (revision without full rejection).
3. **AI is assistive**: AI answers and suggestions are surfaced to moderators/members but require human review before being marked authoritative.
4. **Invite-only onboarding**: No self-registration. Admins generate invite codes tied to an organization, subject to per-organisation `max_users` limits enforced at invite generation and signup.
5. **Async processing**: Heavy operations (OCR, embedding, translation) run via Celery workers, never blocking API responses.
6. **Multi-language via English pivot**: All AI processing happens in English. Non-English input is translated to English before RAG retrieval; the output is translated back to the user's preferred language. User language preference is stored on the profile.
7. **Q&A as knowledge base**: Approved question+answer pairs are embedded into the vector DB alongside document chunks, making the Q&A corpus searchable via RAG — not just static documents.
