BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- -----------------------------------------------------------------------------
-- Identity, organizations, RBAC, and invite-only onboarding
-- -----------------------------------------------------------------------------

CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    organization_type VARCHAR(50) NOT NULL DEFAULT 'MEMBER_ORG'
        CHECK (organization_type IN ('ICA_OFFICE', 'MEMBER_ORG', 'PARTNER', 'PUBLIC')),
    country_code CHAR(2),
    region VARCHAR(100),
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email CITEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    job_title VARCHAR(150),
    locale VARCHAR(20) NOT NULL DEFAULT 'en',
    primary_organization_id UUID REFERENCES organizations(id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE organization_memberships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    membership_status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE'
        CHECK (membership_status IN ('PENDING', 'ACTIVE', 'SUSPENDED', 'REVOKED')),
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (organization_id, user_id)
);

CREATE UNIQUE INDEX ux_memberships_primary_user
    ON organization_memberships (user_id)
    WHERE is_primary = TRUE;

CREATE TABLE roles (
    id SMALLSERIAL PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE permissions (
    id SMALLSERIAL PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    description TEXT
);

CREATE TABLE role_permissions (
    role_id SMALLINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id SMALLINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id SMALLINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    assigned_by UUID REFERENCES users(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ,
    UNIQUE (user_id, role_id, organization_id)
);

CREATE TABLE invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email CITEXT,
    invite_code VARCHAR(100) NOT NULL UNIQUE,
    invited_role_id SMALLINT REFERENCES roles(id),
    invited_by UUID REFERENCES users(id),
    max_uses INTEGER NOT NULL DEFAULT 1 CHECK (max_uses > 0),
    used_count INTEGER NOT NULL DEFAULT 0 CHECK (used_count >= 0),
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'EXPIRED', 'REVOKED', 'CONSUMED')),
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_users_primary_org ON users (primary_organization_id);
CREATE INDEX ix_user_roles_user ON user_roles (user_id);
CREATE INDEX ix_user_roles_org ON user_roles (organization_id);
CREATE INDEX ix_invitations_org_status ON invitations (organization_id, status);

-- -----------------------------------------------------------------------------
-- Shared classification metadata
-- -----------------------------------------------------------------------------

CREATE TABLE tags (
    id BIGSERIAL PRIMARY KEY,
    tag_type VARCHAR(50) NOT NULL DEFAULT 'GENERAL'
        CHECK (tag_type IN ('GENERAL', 'TOPIC', 'COUNTRY', 'LAW_TYPE', 'LANGUAGE', 'NEWS', 'QNA')),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tag_type, name)
);

CREATE TABLE categories (
    id BIGSERIAL PRIMARY KEY,
    category_type VARCHAR(50) NOT NULL
        CHECK (category_type IN ('DOCUMENT', 'QUESTION', 'NEWS', 'POST', 'KNOWLEDGE_ARTICLE')),
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(140) NOT NULL UNIQUE,
    parent_id BIGINT REFERENCES categories(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (category_type, name)
);

-- -----------------------------------------------------------------------------
-- File storage and document repository
-- -----------------------------------------------------------------------------

CREATE TABLE stored_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    storage_provider VARCHAR(30) NOT NULL DEFAULT 'S3'
        CHECK (storage_provider IN ('S3', 'AZURE_BLOB', 'MINIO', 'LOCAL')),
    bucket_name VARCHAR(255),
    object_key TEXT NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(120),
    file_size_bytes BIGINT CHECK (file_size_bytes >= 0),
    checksum_sha256 CHAR(64),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id),
    owner_user_id UUID REFERENCES users(id),
    category_id BIGINT REFERENCES categories(id),
    title TEXT NOT NULL,
    slug VARCHAR(180) NOT NULL UNIQUE,
    summary TEXT,
    source_type VARCHAR(30) NOT NULL DEFAULT 'UPLOAD'
        CHECK (source_type IN ('UPLOAD', 'EXTERNAL_LINK', 'MANUAL_ENTRY')),
    source_url TEXT,
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'ORG'
        CHECK (visibility_scope IN ('PRIVATE', 'ORG', 'ICA', 'PUBLIC')),
    lifecycle_status VARCHAR(30) NOT NULL DEFAULT 'DRAFT'
        CHECK (lifecycle_status IN ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'ARCHIVED')),
    current_version_id UUID,
    original_language_code VARCHAR(10),
    translated_language_codes TEXT[] NOT NULL DEFAULT '{}',
    publication_date DATE,
    effective_date DATE,
    issued_by VARCHAR(255),
    document_number VARCHAR(100),
    search_vector TSVECTOR,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at TIMESTAMPTZ
);

CREATE TABLE document_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL CHECK (version_number > 0),
    stored_file_id UUID REFERENCES stored_files(id),
    extracted_text TEXT,
    translated_text TEXT,
    translation_language_code VARCHAR(10),
    ocr_status VARCHAR(30) NOT NULL DEFAULT 'PENDING'
        CHECK (ocr_status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'NOT_REQUIRED')),
    processing_status VARCHAR(30) NOT NULL DEFAULT 'PENDING'
        CHECK (processing_status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED')),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (document_id, version_number)
);

ALTER TABLE documents
    ADD CONSTRAINT fk_documents_current_version
    FOREIGN KEY (current_version_id) REFERENCES document_versions(id);

CREATE TABLE document_metadata (
    document_id UUID PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
    jurisdiction_country_code CHAR(2),
    jurisdiction_region VARCHAR(100),
    law_type VARCHAR(100),
    subject_area VARCHAR(150),
    language_code VARCHAR(10),
    publication_year INTEGER CHECK (publication_year BETWEEN 1800 AND 3000),
    citation_reference VARCHAR(255),
    issuing_authority VARCHAR(255),
    keywords TEXT[],
    extra_metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE document_tags (
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    tag_id BIGINT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (document_id, tag_id)
);

CREATE TABLE document_localizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    language_code VARCHAR(10) NOT NULL,
    translated_title TEXT,
    translated_summary TEXT,
    translated_text TEXT,
    translation_provider VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (document_id, language_code)
);

CREATE INDEX ix_documents_org_status ON documents (organization_id, lifecycle_status);
CREATE INDEX ix_documents_visibility_status ON documents (visibility_scope, lifecycle_status);
CREATE INDEX ix_documents_publication_date ON documents (publication_date DESC);
CREATE INDEX ix_documents_search_vector ON documents USING GIN (search_vector);
CREATE INDEX ix_document_versions_doc_version ON document_versions (document_id, version_number DESC);
CREATE INDEX ix_document_metadata_country_law ON document_metadata (jurisdiction_country_code, law_type);

-- -----------------------------------------------------------------------------
-- AI / RAG readiness and external vector-store traceability
-- -----------------------------------------------------------------------------

CREATE TABLE embedding_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50) NOT NULL
        CHECK (entity_type IN ('DOCUMENT_CHUNK', 'QUESTION', 'ANSWER', 'KNOWLEDGE_ARTICLE', 'NEWS_ITEM')),
    entity_id UUID NOT NULL,
    provider VARCHAR(100) NOT NULL,
    model_name VARCHAR(150) NOT NULL,
    vector_namespace VARCHAR(150),
    vector_reference TEXT NOT NULL,
    dimensions INTEGER CHECK (dimensions > 0),
    embedding_status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE'
        CHECK (embedding_status IN ('PENDING', 'ACTIVE', 'STALE', 'DELETED', 'FAILED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (entity_type, entity_id, provider, model_name)
);

CREATE TABLE document_chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_version_id UUID NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL CHECK (chunk_index >= 0),
    page_number INTEGER CHECK (page_number > 0),
    section_title VARCHAR(255),
    chunk_text TEXT NOT NULL,
    token_count INTEGER CHECK (token_count >= 0),
    embedding_record_id UUID REFERENCES embedding_records(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (document_version_id, chunk_index)
);

CREATE INDEX ix_document_chunks_doc_version ON document_chunks (document_version_id, chunk_index);
CREATE INDEX ix_embedding_records_entity ON embedding_records (entity_type, entity_id);

-- -----------------------------------------------------------------------------
-- Q&A, citations, and reusable knowledge conversion
-- -----------------------------------------------------------------------------

CREATE TABLE questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id),
    asked_by UUID NOT NULL REFERENCES users(id),
    category_id BIGINT REFERENCES categories(id),
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'ORG'
        CHECK (visibility_scope IN ('PRIVATE', 'ORG', 'ICA', 'PUBLIC')),
    workflow_status VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (workflow_status IN ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'ANSWERED', 'CLOSED', 'ARCHIVED')),
    priority_level SMALLINT NOT NULL DEFAULT 3 CHECK (priority_level BETWEEN 1 AND 5),
    is_ai_assistance_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    published_at TIMESTAMPTZ,
    closed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE question_tags (
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    tag_id BIGINT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (question_id, tag_id)
);

CREATE TABLE question_attachments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    stored_file_id UUID NOT NULL REFERENCES stored_files(id) ON DELETE CASCADE,
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_answer_suggestions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    provider VARCHAR(100) NOT NULL,
    model_name VARCHAR(150) NOT NULL,
    prompt_version VARCHAR(50),
    draft_answer TEXT NOT NULL,
    citations JSONB NOT NULL DEFAULT '[]'::JSONB,
    confidence_score NUMERIC(5, 2) CHECK (confidence_score BETWEEN 0 AND 100),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE answers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    answered_by UUID NOT NULL REFERENCES users(id),
    answer_text TEXT NOT NULL,
    answer_source VARCHAR(30) NOT NULL DEFAULT 'HUMAN'
        CHECK (answer_source IN ('HUMAN', 'AI_DRAFT', 'AI_ASSISTED')),
    workflow_status VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (workflow_status IN ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'ARCHIVED')),
    is_official BOOLEAN NOT NULL DEFAULT FALSE,
    is_accepted BOOLEAN NOT NULL DEFAULT FALSE,
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX ux_answers_question_id_id ON answers (question_id, id);

ALTER TABLE questions
    ADD COLUMN accepted_answer_id UUID;

ALTER TABLE questions
    ADD CONSTRAINT fk_questions_accepted_answer
    FOREIGN KEY (id, accepted_answer_id) REFERENCES answers(question_id, id);

CREATE TABLE answer_citations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    answer_id UUID NOT NULL REFERENCES answers(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id),
    document_chunk_id UUID REFERENCES document_chunks(id),
    citation_label VARCHAR(255),
    page_number INTEGER CHECK (page_number > 0),
    excerpt TEXT,
    citation_order INTEGER NOT NULL DEFAULT 1 CHECK (citation_order > 0)
);

CREATE TABLE knowledge_articles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_question_id UUID REFERENCES questions(id),
    source_answer_id UUID REFERENCES answers(id),
    organization_id UUID REFERENCES organizations(id),
    category_id BIGINT REFERENCES categories(id),
    title TEXT NOT NULL,
    slug VARCHAR(180) NOT NULL UNIQUE,
    summary TEXT,
    body TEXT NOT NULL,
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'ICA'
        CHECK (visibility_scope IN ('PRIVATE', 'ORG', 'ICA', 'PUBLIC')),
    workflow_status VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (workflow_status IN ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'ARCHIVED')),
    approved_by UUID REFERENCES users(id),
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE knowledge_article_citations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    knowledge_article_id UUID NOT NULL REFERENCES knowledge_articles(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id),
    document_chunk_id UUID REFERENCES document_chunks(id),
    answer_id UUID REFERENCES answers(id),
    citation_order INTEGER NOT NULL DEFAULT 1 CHECK (citation_order > 0),
    excerpt TEXT
);

CREATE INDEX ix_questions_org_status ON questions (organization_id, workflow_status);
CREATE INDEX ix_questions_visibility_status ON questions (visibility_scope, workflow_status);
CREATE INDEX ix_answers_question_status ON answers (question_id, workflow_status);
CREATE INDEX ix_knowledge_articles_status ON knowledge_articles (workflow_status, published_at DESC);

-- -----------------------------------------------------------------------------
-- News and lightweight collaboration
-- -----------------------------------------------------------------------------

CREATE TABLE news_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id),
    submitted_by UUID REFERENCES users(id),
    category_id BIGINT REFERENCES categories(id),
    title TEXT NOT NULL,
    slug VARCHAR(180) NOT NULL UNIQUE,
    summary TEXT,
    content TEXT NOT NULL,
    source_url TEXT,
    language_code VARCHAR(10),
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'ICA'
        CHECK (visibility_scope IN ('ORG', 'ICA', 'PUBLIC')),
    workflow_status VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (workflow_status IN ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'ARCHIVED')),
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE news_tags (
    news_item_id UUID NOT NULL REFERENCES news_items(id) ON DELETE CASCADE,
    tag_id BIGINT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (news_item_id, tag_id)
);

CREATE TABLE posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id),
    user_id UUID NOT NULL REFERENCES users(id),
    title TEXT,
    content TEXT NOT NULL,
    visibility_scope VARCHAR(30) NOT NULL DEFAULT 'ORG'
        CHECK (visibility_scope IN ('PRIVATE', 'ORG', 'ICA', 'PUBLIC')),
    workflow_status VARCHAR(30) NOT NULL DEFAULT 'PUBLISHED'
        CHECK (workflow_status IN ('DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'REJECTED', 'ARCHIVED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE post_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    parent_comment_id UUID REFERENCES post_comments(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL
        CHECK (entity_type IN ('POST', 'COMMENT', 'ANSWER', 'KNOWLEDGE_ARTICLE', 'NEWS_ITEM')),
    entity_id UUID NOT NULL,
    reaction_type VARCHAR(30) NOT NULL DEFAULT 'LIKE'
        CHECK (reaction_type IN ('LIKE', 'ENDORSE', 'INSIGHTFUL')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, entity_type, entity_id, reaction_type)
);

CREATE TABLE bookmarks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL
        CHECK (entity_type IN ('DOCUMENT', 'QUESTION', 'ANSWER', 'KNOWLEDGE_ARTICLE', 'NEWS_ITEM', 'POST')),
    entity_id UUID NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, entity_type, entity_id)
);

CREATE TABLE follows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follower_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    followed_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (follower_user_id <> followed_user_id),
    UNIQUE (follower_user_id, followed_user_id)
);

CREATE INDEX ix_news_items_status_published ON news_items (workflow_status, published_at DESC);
CREATE INDEX ix_posts_org_created ON posts (organization_id, created_at DESC);
CREATE INDEX ix_reactions_entity ON reactions (entity_type, entity_id);
CREATE INDEX ix_bookmarks_user ON bookmarks (user_id, created_at DESC);

-- -----------------------------------------------------------------------------
-- Moderation, audit, notifications, and async outbox
-- -----------------------------------------------------------------------------

CREATE TABLE moderation_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50) NOT NULL
        CHECK (entity_type IN ('DOCUMENT', 'QUESTION', 'ANSWER', 'KNOWLEDGE_ARTICLE', 'NEWS_ITEM', 'POST', 'COMMENT')),
    entity_id UUID NOT NULL,
    submitted_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    priority_level SMALLINT NOT NULL DEFAULT 3 CHECK (priority_level BETWEEN 1 AND 5),
    moderation_status VARCHAR(30) NOT NULL DEFAULT 'PENDING'
        CHECK (moderation_status IN ('PENDING', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'CHANGES_REQUESTED', 'ESCALATED')),
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMPTZ,
    resolution_notes TEXT,
    UNIQUE (entity_type, entity_id)
);

CREATE TABLE moderation_actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    moderation_queue_id UUID NOT NULL REFERENCES moderation_queue(id) ON DELETE CASCADE,
    action_by UUID REFERENCES users(id),
    action_type VARCHAR(30) NOT NULL
        CHECK (action_type IN ('SUBMITTED', 'ASSIGNED', 'APPROVED', 'REJECTED', 'COMMENTED', 'ESCALATED', 'REQUESTED_CHANGES')),
    remarks TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(255) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    ip_address INET,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preferences (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    email_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    in_app_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    notify_on_questions BOOLEAN NOT NULL DEFAULT TRUE,
    notify_on_answers BOOLEAN NOT NULL DEFAULT TRUE,
    notify_on_news BOOLEAN NOT NULL DEFAULT TRUE,
    notify_on_moderation BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    notification_type VARCHAR(50) NOT NULL
        CHECK (notification_type IN ('QUESTION', 'ANSWER', 'NEWS', 'MODERATION', 'SYSTEM', 'MENTION')),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE outbox_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type VARCHAR(50) NOT NULL,
    aggregate_id UUID NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    processing_status VARCHAR(30) NOT NULL DEFAULT 'PENDING'
        CHECK (processing_status IN ('PENDING', 'PROCESSING', 'PUBLISHED', 'FAILED', 'DEAD_LETTER')),
    available_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at TIMESTAMPTZ,
    retry_count INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_moderation_queue_status_priority
    ON moderation_queue (moderation_status, priority_level, submitted_at);
CREATE INDEX ix_moderation_actions_queue_created
    ON moderation_actions (moderation_queue_id, created_at);
CREATE INDEX ix_audit_logs_entity_created
    ON audit_logs (entity_type, entity_id, created_at DESC);
CREATE INDEX ix_notifications_user_read_created
    ON notifications (user_id, is_read, created_at DESC);
CREATE INDEX ix_outbox_events_status_available
    ON outbox_events (processing_status, available_at);

COMMIT;
