# PostgreSQL Data Model Notes

This schema is based on the attached PDF suggestions and expands them into a fuller production-ready relational model for the ICA cooperative law platform.

It is designed to cover the current MVP and the near-term scale-up use cases:

- Invite-only onboarding with organization-aware RBAC
- Legal document repository with versions, metadata, OCR text, translations, and tags
- AI-ready chunking plus external embedding/vector references
- Moderated Q&A with AI draft suggestions, citations, and reusable knowledge articles
- News publishing and lightweight professional collaboration
- Notifications, bookmarks, reactions, audit logging, and moderation history
- Async outbox support for search indexing, embedding generation, and notification workers

## Main design choices

- PostgreSQL remains the source of truth for transactional and workflow data.
- Search and vector stores are represented through bridge tables instead of storing indexes directly in PostgreSQL.
- Moderation is generic and can be reused across documents, questions, answers, news, and social content.
- Social features stay intentionally lightweight to match the product direction in `AGENTS.md`.
- The schema uses `TIMESTAMPTZ`, `UUID`, `JSONB`, and `CITEXT` to fit the platform's auditability and multi-tenant needs.

## Suggested rollout order

1. Identity, memberships, roles, invitations
2. Document repository and metadata
3. Q&A, answers, and citations
4. Moderation and audit logging
5. News, posts, notifications
6. AI chunking, embedding registry, outbox events

## File

- SQL DDL: [postgresql-data-model-ddl.sql](/D:/PythonWorkspace/poc-restricted-social-platform/Docs/postgresql-data-model-ddl.sql)
