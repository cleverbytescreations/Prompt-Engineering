# ICA Platform — Full Task List

> Status: `[ ]` = Incomplete, `[x]` = Done  
> Reference: `implementation-plan.md` for API contracts, `ui-screen-list.txt` for screens

---

## PHASE 0 — Project Setup & Infrastructure

### 0.1 Repository & Tooling
- [ ] Initialize monorepo structure (`/frontend`, `/backend`, `/Docs`)
- [ ] Set up `.gitignore` for Python, Node, environment files
- [ ] Create root `README.md` with setup instructions
- [ ] Set up pre-commit hooks (lint + format checks)

### 0.2 Docker & Local Environment
- [ ] Write `docker-compose.yml` with services: frontend, backend, postgres, redis, minio, worker
- [ ] Create `Dockerfile` for backend (FastAPI + Celery)
- [ ] Create `Dockerfile` for frontend (Next.js)
- [ ] Configure environment variable templates (`.env.example`)
- [ ] Verify all services start cleanly with `docker compose up`
- [ ] Configure MinIO bucket for document storage

### 0.3 Database Setup
- [ ] Configure PostgreSQL connection in backend
- [ ] Set up Alembic for database migrations
- [ ] Create initial migration with all core tables:
  - `users`, `organizations`, `invites`
  - `documents`, `document_chunks`
  - `questions`, `answers`
  - `news`, `posts`, `post_comments`, `post_likes`
  - `moderation_logs`
  - `notifications`
  - `tags`, `countries`, `categories`
- [ ] Seed reference data: countries, categories, tags
- [ ] Seed admin user and test organization

---

## PHASE 1 — Backend: Core API

### 1.1 Project Structure & Foundation
- [ ] Scaffold FastAPI project with clean architecture layout (`api/`, `services/`, `repositories/`, `models/`, `schemas/`, `core/`)
- [ ] Configure app settings with Pydantic BaseSettings (env-driven)
- [ ] Set up database session management (async SQLAlchemy)
- [ ] Implement global exception handlers (404, 422, 500)
- [ ] Set up CORS middleware
- [ ] Configure structured logging
- [ ] Set up API versioning prefix `/api/v1`
- [ ] Write health check endpoint `GET /health`

### 1.2 Auth & Onboarding API
- [ ] `POST /api/v1/auth/verify-invite` — Validate invite code, return org info
- [ ] `POST /api/v1/auth/signup` — Register user with invite code, create profile
- [ ] `POST /api/v1/auth/login` — Authenticate, return JWT access + refresh tokens
- [ ] `POST /api/v1/auth/logout` — Blacklist token in Redis
- [ ] `POST /api/v1/auth/forgot-password` — Generate reset token, queue email
- [ ] `POST /api/v1/auth/reset-password` — Validate token, update password
- [ ] `POST /api/v1/auth/refresh-token` — Issue new access token
- [ ] `GET /api/v1/auth/me` — Return current user profile
- [ ] `PATCH /api/v1/auth/me` — Update own profile fields
- [ ] `POST /api/v1/auth/me/preferences` — Save country/domain interests
- [ ] Implement JWT utility (create, decode, validate)
- [ ] Implement password hashing (bcrypt)
- [ ] Implement `get_current_user` dependency
- [ ] Implement role-based access control (RBAC) dependency guards

### 1.3 User Management API
- [ ] `GET /api/v1/users` — List users with pagination and filters (role, org, status)
- [ ] `GET /api/v1/users/{id}` — Get user profile
- [ ] `PUT /api/v1/users/{id}` — Admin update user profile
- [ ] `DELETE /api/v1/users/{id}` — Soft delete / deactivate user
- [ ] `PATCH /api/v1/users/{id}/status` — Activate or deactivate account
- [ ] `PATCH /api/v1/users/{id}/role` — Assign role (admin/moderator/member)
- [ ] `GET /api/v1/users/{id}/contributions` — Return questions, docs, posts count + list

### 1.4 Organization Management API
- [ ] `GET /api/v1/organizations` — List all organizations
- [ ] `POST /api/v1/organizations` — Create organization
- [ ] `GET /api/v1/organizations/{id}` — Get organization details
- [ ] `PUT /api/v1/organizations/{id}` — Update organization (name, max_users)
- [ ] `DELETE /api/v1/organizations/{id}` — Delete organization
- [ ] `GET /api/v1/organizations/{id}/members` — List members of an organization

### 1.5 Invite Management API
- [ ] `POST /api/v1/invites` — Generate invite code (admin only), link to org
- [ ] `GET /api/v1/invites` — List all invites with status
- [ ] `GET /api/v1/invites/{code}` — Get invite detail and status
- [ ] `DELETE /api/v1/invites/{code}` — Revoke invite code

### 1.6 Knowledge Repository (Documents) API
- [ ] `POST /api/v1/documents` — Upload PDF to MinIO/S3, create DB record (status: pending)
- [ ] `GET /api/v1/documents` — List approved documents with filters (country, category, tag, search)
- [ ] `GET /api/v1/documents/{id}` — Get document detail + metadata
- [ ] `PUT /api/v1/documents/{id}` — Update document metadata
- [ ] `DELETE /api/v1/documents/{id}` — Delete document record + file
- [ ] `GET /api/v1/documents/{id}/download` — Generate presigned download URL
- [ ] `GET /api/v1/documents/{id}/related` — Return related documents (initially by category/country, later AI)
- [ ] `GET /api/v1/documents/my` — Current user's uploaded documents
- [ ] `GET /api/v1/documents/{id}/status` — Fetch moderation status of a document
- [ ] Implement file upload service (multipart, MinIO integration)
- [ ] Implement presigned URL generation for downloads

### 1.7 Question & Answer API
- [ ] `POST /api/v1/questions` — Submit question (status: pending)
- [ ] `GET /api/v1/questions` — List approved questions with filters (country, category, tag, search)
- [ ] `GET /api/v1/questions/{id}` — Get question detail
- [ ] `PUT /api/v1/questions/{id}` — Edit question (owner or admin)
- [ ] `DELETE /api/v1/questions/{id}` — Delete question (admin)
- [ ] `GET /api/v1/questions/my` — Current user's questions with status
- [ ] `POST /api/v1/questions/{question_id}/answers` — Post an answer
- [ ] `GET /api/v1/questions/{question_id}/answers` — List answers for a question
- [ ] `PUT /api/v1/answers/{id}` — Edit an answer
- [ ] `DELETE /api/v1/answers/{id}` — Delete an answer (admin)
- [ ] `PATCH /api/v1/answers/{id}/accept` — Mark answer as accepted (question owner)

### 1.8 News & Updates API
- [ ] `POST /api/v1/news` — Submit news (status: pending)
- [ ] `GET /api/v1/news` — List approved news with filters (country, category, tag)
- [ ] `GET /api/v1/news/{id}` — Get news article detail
- [ ] `PUT /api/v1/news/{id}` — Update news article
- [ ] `DELETE /api/v1/news/{id}` — Delete news article (admin)
- [ ] `GET /api/v1/news/my` — Current user's submitted news with status

### 1.9 Social Feed / Posts API
- [ ] `POST /api/v1/posts` — Create a post (status: pending)
- [ ] `GET /api/v1/posts` — List approved posts (feed)
- [ ] `GET /api/v1/posts/{id}` — Get post detail
- [ ] `PUT /api/v1/posts/{id}` — Edit post
- [ ] `DELETE /api/v1/posts/{id}` — Delete post (admin)
- [ ] `POST /api/v1/posts/{id}/like` — Toggle like on a post
- [ ] `GET /api/v1/posts/{id}/comments` — Get comments for a post
- [ ] `POST /api/v1/posts/{id}/comments` — Add comment to a post
- [ ] `DELETE /api/v1/posts/{id}/comments/{cid}` — Delete a comment (admin/moderator)

### 1.10 Moderation API
- [ ] `GET /api/v1/moderation/queue` — Full queue (all types, paginated)
- [ ] `GET /api/v1/moderation/queue/questions` — Pending questions
- [ ] `GET /api/v1/moderation/queue/documents` — Pending documents
- [ ] `GET /api/v1/moderation/queue/news` — Pending news
- [ ] `GET /api/v1/moderation/queue/posts` — Pending posts
- [ ] `POST /api/v1/moderation/approve` — Approve an item (entity_type + entity_id)
- [ ] `POST /api/v1/moderation/reject` — Reject an item with remarks
- [ ] `GET /api/v1/moderation/logs` — Full audit log (paginated)
- [ ] `GET /api/v1/moderation/logs/{entity_type}/{id}` — Moderation history for an item
- [ ] `GET /api/v1/moderation/stats` — Queue counts by type (for dashboard badge)
- [ ] Dispatch notification to submitter on approve/reject

### 1.11 Notifications API
- [ ] `GET /api/v1/notifications` — List user's notifications (paginated)
- [ ] `GET /api/v1/notifications/unread-count` — Get unread count (for badge)
- [ ] `PATCH /api/v1/notifications/{id}/read` — Mark single notification as read
- [ ] `PATCH /api/v1/notifications/read-all` — Mark all as read
- [ ] `DELETE /api/v1/notifications/{id}` — Delete notification

### 1.12 Dashboard API
- [ ] `GET /api/v1/dashboard` — Aggregated: latest news (5), recent questions (5), recent docs (5), unread notif count

### 1.13 Search API
- [ ] `GET /api/v1/search` — Keyword search across documents, questions, news (query params: `q`, `type`, `country`, `category`, `tag`, `page`, `limit`)

### 1.14 Taxonomy / Reference Data API
- [ ] `GET /api/v1/tags` — List all tags
- [ ] `GET /api/v1/countries` — List all supported countries
- [ ] `GET /api/v1/categories` — List all categories

---

## PHASE 2 — Backend: AI & Async Processing

### 2.1 Celery Worker Setup
- [ ] Configure Celery with Redis broker
- [ ] Set up task routing and queues (ingestion, embedding, notifications)
- [ ] Implement task status tracking

### 2.2 Document Ingestion Pipeline
- [ ] Implement `document_ingestion_job` — OCR from PDF using Tesseract
- [ ] Implement `chunking_job` — Split extracted text into semantic chunks, store in `document_chunks`
- [ ] Trigger ingestion pipeline automatically on document approval

### 2.3 AI / RAG Pipeline
- [ ] Set up sentence-transformers or OpenAI embedding model
- [ ] Implement `embedding_generation_job` — Generate embeddings for chunks, store in FAISS index
- [ ] Persist FAISS index to disk (reload on startup)
- [ ] Implement RAG retrieval function (query → nearest chunks → LLM prompt)
- [ ] Implement `ai_answer_job` — async RAG answer generation
- [ ] `POST /api/v1/ai/ask` — Accept question, trigger job, return answer + sources
- [ ] `GET /api/v1/ai/suggestions/{question_id}` — Return AI-suggested answer for moderator review
- [ ] `POST /api/v1/ai/summarize/{document_id}` — Return AI summary of document
- [ ] `POST /api/v1/ai/related/{document_id}` — Semantic similarity search for related docs

### 2.4 Notification Dispatch
- [ ] Implement `notification_dispatch_job` — Create notification records on moderation actions
- [ ] Notify question owner when their question is answered
- [ ] Notify submitter on approval or rejection of any content

---

## PHASE 3 — Frontend: Next.js Application

### 3.1 Project Setup
- [ ] Initialize Next.js with App Router and TypeScript
- [ ] Install and configure Tailwind CSS
- [ ] Install Material UI (MUI) component library
- [ ] Set up React Query (TanStack Query) for API state
- [ ] Set up Zustand for global auth state
- [ ] Configure API base URL via environment variable
- [ ] Create typed API client (axios or fetch wrapper)
- [ ] Create custom React Query hooks per module
- [ ] Set up auth middleware (route protection)
- [ ] Configure Next.js PWA (`next-pwa`)

### 3.2 Shared / Layout Components
- [ ] `AppLayout.tsx` — Main layout with sidebar, header, notification bell
- [ ] `Sidebar.tsx` — Navigation links (role-aware visibility)
- [ ] `Header.tsx` — Logo, search bar, user menu, notification badge
- [ ] `NotificationBell.tsx` — Shows unread count, links to `/notifications`
- [ ] `LoadingSpinner.tsx` / `PageSkeleton.tsx`
- [ ] `EmptyState.tsx`
- [ ] `ErrorBoundary.tsx`
- [ ] `ConfirmDialog.tsx`
- [ ] `StatusBadge.tsx` — Pending / Approved / Rejected badge
- [ ] `Pagination.tsx`
- [ ] `FilterBar.tsx` — Country, category, tag filters (reusable)
- [ ] `RichTextEditor.tsx` — For questions, answers, posts (react-quill or tiptap)

### 3.3 Auth Module (Pages & Components)
- [ ] `/auth/login` — `LoginForm.tsx` (email + password, JWT storage)
- [ ] `/auth/signup` — `InviteSignup.tsx` (invite code step → org display → profile form)
- [ ] `/auth/forgot-password` — `ForgotPasswordForm.tsx`
- [ ] `/auth/reset-password` — `ResetPasswordForm.tsx` (token from URL)
- [ ] `/auth/setup` — `UserSetupForm.tsx` (select countries + domains of interest)
- [ ] Implement auth context / Zustand store (token, user, role)
- [ ] Implement protected route wrapper
- [ ] Auto-redirect logged-in users away from auth pages

### 3.4 Dashboard (Page & Widgets)
- [ ] `/dashboard` — `DashboardPage.tsx`
- [ ] `LatestNewsWidget.tsx` — 5 latest approved news items
- [ ] `RecentQuestionsWidget.tsx` — 5 latest approved questions
- [ ] `RecentDocumentsWidget.tsx` — 5 recently added documents
- [ ] `NotificationsSummaryWidget.tsx` — Unread count + 3 latest notifications
- [ ] Role-aware widgets (moderator sees pending count badges)

### 3.5 Knowledge Repository Module
- [ ] `/repository` — `DocumentListPage.tsx` with `FilterBar`, search, document cards
- [ ] `/repository/[id]` — `DocumentDetailPage.tsx` (metadata, PDF preview, download, related)
- [ ] `DocumentViewer.tsx` — Embed `react-pdf` for inline PDF display
- [ ] `/repository/upload` — `UploadDocumentForm.tsx` (file picker, metadata fields, submit)
- [ ] `/repository/my` — `MyDocumentsPage.tsx` with status badges
- [ ] `DocumentCard.tsx` — Reusable card for list views

### 3.6 Question & Answer Module
- [ ] `/questions` — `QuestionListPage.tsx` with filters and search
- [ ] `/questions/ask` — `AskQuestionPage.tsx` with `RichTextEditor` and tag selection
- [ ] `/questions/[id]` — `QuestionDetailPage.tsx` (question, answers, post answer form, AI suggestion box)
- [ ] `/questions/my` — `MyQuestionsPage.tsx` with status column
- [ ] `QuestionCard.tsx` — Reusable card for list
- [ ] `AnswerCard.tsx` — Shows answer with accept button if owner
- [ ] `AIAnswerBox.tsx` — Collapsible AI suggestion (labeled clearly as AI)
- [ ] `PostAnswerForm.tsx` — Rich text reply form

### 3.7 News Module
- [ ] `/news` — `NewsFeedPage.tsx` with tag/country filters
- [ ] `/news/[id]` — `NewsDetailPage.tsx` (full content, source, related docs)
- [ ] `/news/create` — `SubmitNewsForm.tsx` (title, content/link, category)
- [ ] `NewsCard.tsx` — Reusable card for list

### 3.8 Social Feed Module
- [ ] `/feed` — `SocialFeedPage.tsx` (list of posts)
- [ ] `/post/create` — `CreatePostPage.tsx` (text editor + optional document attach)
- [ ] `PostCard.tsx` — Post with like count, comment toggle
- [ ] `CommentSection.tsx` — Inline comment list + input

### 3.9 User Profile Module
- [ ] `/profile/[id]` — `UserProfilePage.tsx` (name, org, contributions: questions, docs, posts)
- [ ] `/profile/edit` — `EditProfilePage.tsx` (own profile)

### 3.10 Notifications Module
- [ ] `/notifications` — `NotificationsPage.tsx` (full list, mark all read)
- [ ] `NotificationItem.tsx` — Single notification row with read/unread styling

### 3.11 Moderation Module
- [ ] `/moderation` — `ModerationDashboard.tsx` (tabs: Questions, Documents, News, Posts)
- [ ] `ModerationQueue.tsx` — Paginated list of pending items per tab
- [ ] `ReviewPanel.tsx` — Side panel / modal: show content + Approve / Reject + remarks input
- [ ] Optimistic UI update on approve/reject (remove from queue immediately)

### 3.12 Admin Module
- [ ] `/admin/users` — `UserManagementPage.tsx` (table: name, org, role, status + actions)
- [ ] `/admin/orgs` — `OrgManagementPage.tsx` (list orgs, create/edit, see member count)
- [ ] `/admin/invites` — `InviteManagementPage.tsx` (generate code, list active, revoke)
- [ ] `/admin/analytics` — `AnalyticsDashboard.tsx` (content counts, moderation stats)

### 3.13 Search & AI Module
- [ ] `/search` — `GlobalSearchPage.tsx` (search bar, results grouped: Documents / Questions / News)
- [ ] `SearchResultCard.tsx` — Unified card for mixed results
- [ ] `AIAnswerPanel.tsx` — Full AI Q&A interface with source citations

### 3.14 Language Support (Light)
- [ ] Install and configure `next-intl` or `i18next`
- [ ] Create translation files for EN, ES, FR (key strings only)
- [ ] `LanguageSwitcher.tsx` — Dropdown in header

---

## PHASE 4 — Testing

### 4.1 Backend Tests
- [ ] Set up pytest with async support
- [ ] Configure test database (SQLite or PostgreSQL test schema)
- [ ] Write unit tests for auth service (login, signup, token)
- [ ] Write unit tests for user and org service
- [ ] Write unit tests for document service
- [ ] Write unit tests for question + answer service
- [ ] Write unit tests for news service
- [ ] Write unit tests for moderation service
- [ ] Write integration tests for complete moderation workflow (submit → approve → visible)
- [ ] Write integration tests for Q&A flow (ask → moderate → answer)
- [ ] Write integration tests for document upload + download

### 4.2 Frontend Tests
- [ ] Set up Jest + React Testing Library
- [ ] Write unit tests for auth forms (login, signup)
- [ ] Write unit tests for `FilterBar`, `StatusBadge`, `Pagination`
- [ ] Write smoke tests for page rendering (dashboard, questions, repository)

### 4.3 API Contract Tests
- [ ] Export OpenAPI schema from FastAPI
- [ ] Verify all endpoints listed in `implementation-plan.md` are present
- [ ] Test all endpoints with Postman / Bruno collection (one request per endpoint)

---

## PHASE 5 — Security & Quality

### 5.1 Security
- [ ] Validate all input with Pydantic schemas (no raw request passthrough)
- [ ] Enforce RBAC on every protected endpoint
- [ ] Implement rate limiting on auth endpoints (login, signup, forgot-password)
- [ ] Add file type and size validation on document upload
- [ ] Sanitize rich text input before storing (prevent XSS)
- [ ] Ensure presigned URLs expire within a reasonable window
- [ ] Store secrets only in environment variables (no hardcoded values)
- [ ] Enable HTTPS in production (TLS termination at reverse proxy)

### 5.2 Code Quality
- [ ] Configure `ruff` or `flake8` for backend linting
- [ ] Configure `black` for backend formatting
- [ ] Configure ESLint + Prettier for frontend
- [ ] Ensure all API routes have Pydantic request/response schemas
- [ ] Ensure all SQLAlchemy models use typed columns

---

## PHASE 6 — Deployment & DevOps

### 6.1 Docker & Compose
- [ ] Finalize `docker-compose.yml` for full local stack
- [ ] Add `docker-compose.prod.yml` overrides for production settings
- [ ] Test full stack startup: `docker compose up --build`
- [ ] Verify database migrations run on container start (`alembic upgrade head`)
- [ ] Verify seed data loads correctly

### 6.2 CI/CD
- [ ] Create GitHub Actions workflow for backend: lint → test → build
- [ ] Create GitHub Actions workflow for frontend: lint → type-check → build
- [ ] Add Docker image build step to CI

### 6.3 Production Readiness
- [ ] Configure Nginx reverse proxy for frontend and backend
- [ ] Set up environment-specific `.env` files (dev, staging, prod)
- [ ] Configure MinIO bucket policies (private, pre-signed only)
- [ ] Configure Redis persistence settings
- [ ] Write deployment runbook / setup instructions

---

## PHASE 7 — Demo Preparation

### 7.1 Demo Data
- [ ] Create seed script with realistic demo data:
  - 2 organizations, 5 users (1 admin, 1 moderator, 3 members)
  - 5 approved documents (cooperative law PDFs)
  - 10 approved questions (with answers)
  - 5 news articles
  - 5 social posts
  - 3 items pending moderation (to demonstrate workflow)

### 7.2 Demo Flow Verification
- [ ] Login → Dashboard renders correctly
- [ ] Ask question → appears in moderation queue
- [ ] Moderator approves → question visible in list + submitter notified
- [ ] Answer posted → question detail shows answer
- [ ] Navigate to repository → documents filterable by country/category
- [ ] Open document → PDF viewer works, download works
- [ ] News feed loads and detail page renders
- [ ] Moderation panel shows all content types in tabs
- [ ] Global search returns results across types
- [ ] Mobile responsive layout verified (PWA)
- [ ] Language switcher visible in header

---

## Summary Checklist by Module

| Module                    | Backend API | Frontend UI | Tests |
|---------------------------|-------------|-------------|-------|
| Auth & Onboarding         | [ ]         | [ ]         | [ ]   |
| User Management           | [ ]         | [ ]         | [ ]   |
| Organization Management   | [ ]         | [ ]         | [ ]   |
| Invite Management         | [ ]         | [ ]         | [ ]   |
| Knowledge Repository      | [ ]         | [ ]         | [ ]   |
| Question & Answer         | [ ]         | [ ]         | [ ]   |
| News & Updates            | [ ]         | [ ]         | [ ]   |
| Social Feed / Posts       | [ ]         | [ ]         | [ ]   |
| Moderation                | [ ]         | [ ]         | [ ]   |
| Notifications             | [ ]         | [ ]         | [ ]   |
| Dashboard                 | [ ]         | [ ]         | [ ]   |
| Search                    | [ ]         | [ ]         | [ ]   |
| AI / RAG Layer            | [ ]         | [ ]         | [ ]   |
| Admin Panel               | [ ]         | [ ]         | [ ]   |
| Infrastructure / DevOps   | [ ]         | —           | [ ]   |
